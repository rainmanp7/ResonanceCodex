import json
import numpy as np
import math
from collections import defaultdict

class EAMC_GeometricAnalyzer:
    """Proper analyzer for EAMC geometric weight files"""
    
    def __init__(self):
        self.analyses = {}
        
    def analyze_file(self, filename: str, label: str):
        """Analyze an EAMC weight file properly"""
        print(f"\n{'='*80}")
        print(f"DEEP ANALYSIS OF: {label}")
        print('='*80)
        
        try:
            with open(filename, 'r') as f:
                data = json.load(f)
            
            analysis = {
                'filename': filename,
                'label': label,
                'data': data,
                'summary': self._get_summary(data, label)
            }
            
            # Deep analysis of structure
            analysis['meta_analysis'] = self._analyze_meta(data, label)
            analysis['pantheon_analysis'] = self._deep_analyze_pantheon(data, label)
            analysis['commutator_analysis'] = self._analyze_commutator(data, label)
            analysis['dimensional_analysis'] = self._analyze_dimensions(data, label)
            analysis['training_analysis'] = self._analyze_training(data, label)
            
            self.analyses[label] = analysis
            self._print_detailed_report(analysis)
            
            return analysis
            
        except Exception as e:
            print(f"✗ Error analyzing {filename}: {e}")
            import traceback
            traceback.print_exc()
            return None
    
    def _get_summary(self, data: dict, label: str) -> dict:
        """Get basic summary of the file"""
        summary = {
            'total_size': len(json.dumps(data)),
            'top_keys': list(data.keys()),
            'has_commutator': 'holographic_commutator' in data,
            'has_pantheon': 'pantheon' in data or 'meta_pantheon' in data,
            'timestamp': data.get('timestamp'),
            'latent_dim': data.get('latent_dim')
        }
        return summary
    
    def _analyze_meta(self, data: dict, label: str) -> dict:
        """Analyze metadata structure"""
        meta_data = data.get('meta_pantheon' if 'meta_pantheon' in data else 'pantheon')
        if not meta_data:
            return {'error': 'No meta/pantheon found'}
        
        analysis = {
            'type': 'meta_pantheon' if 'meta_pantheon' in data else 'pantheon',
            'size_bytes': len(json.dumps(meta_data)),
            'structure_type': type(meta_data).__name__
        }
        
        if isinstance(meta_data, dict):
            analysis['keys'] = list(meta_data.keys())
            analysis['depth'] = self._calculate_dict_depth(meta_data)
            
            # Look for dimension information
            dimension_info = self._extract_dimensions_from_meta(meta_data)
            analysis['dimensions_found'] = dimension_info['dimensions']
            analysis['dimension_patterns'] = dimension_info['patterns']
        
        return analysis
    
    def _deep_analyze_pantheon(self, data: dict, label: str) -> dict:
        """Deep analysis of pantheon structure"""
        pantheon_key = 'meta_pantheon' if 'meta_pantheon' in data else 'pantheon'
        pantheon_data = data.get(pantheon_key)
        
        if not pantheon_data:
            return {'error': 'No pantheon data found'}
        
        analysis = {
            'key_name': pantheon_key,
            'total_elements': self._count_total_elements(pantheon_data),
            'dimensional_layers': {},
            'geometric_entities': defaultdict(int),
            'max_nesting': 0
        }
        
        # Deep scan for geometric patterns
        self._deep_scan_geometric(pantheon_data, analysis, current_path="", depth=0)
        
        return analysis
    
    def _analyze_commutator(self, data: dict, label: str) -> dict:
        """Analyze holographic commutator"""
        if 'holographic_commutator' not in data:
            return {'present': False}
        
        commutator = data['holographic_commutator']
        analysis = {
            'present': True,
            'size': len(json.dumps(commutator)),
            'type': type(commutator).__name__,
            'operations': self._scan_for_operations(commutator),
            'dimensional_operations': self._find_dimensional_ops(commutator),
            'warp_indicators': self._find_warp_indicators(commutator)
        }
        
        # Check if it's actually a geometric structure
        if isinstance(commutator, dict):
            analysis['structure'] = 'dictionary'
            analysis['keys'] = list(commutator.keys())
        elif isinstance(commutator, list):
            analysis['structure'] = 'list/array'
            analysis['length'] = len(commutator)
            if commutator and isinstance(commutator[0], (int, float)):
                analysis['element_type'] = 'numeric'
            elif commutator and isinstance(commutator[0], list):
                analysis['element_type'] = 'matrix'
        
        return analysis
    
    def _analyze_dimensions(self, data: dict, label: str) -> dict:
        """Specifically analyze dimension information"""
        dimensions = set()
        dimension_patterns = []
        
        # Check all data for dimensions
        def scan_for_dims(obj, path=""):
            if isinstance(obj, dict):
                for key, value in obj.items():
                    # Check key for dimension info
                    key_str = str(key)
                    if any(str(d) in key_str for d in range(3, 13)):
                        for d in range(3, 13):
                            if str(d) in key_str:
                                dimensions.add(d)
                                dimension_patterns.append(f"{path}.{key}")
                    
                    # Check value for dimensions
                    if isinstance(value, (int, float)):
                        if 3 <= value <= 12:
                            dimensions.add(int(value))
                            dimension_patterns.append(f"{path}.{key} = {value}")
                    elif isinstance(value, list):
                        # Check list length (could indicate dimension)
                        if 3 <= len(value) <= 12:
                            dimensions.add(len(value))
                            dimension_patterns.append(f"{path}.{key}[len={len(value)}]")
                    
                    scan_for_dims(value, f"{path}.{key}")
            
            elif isinstance(obj, list):
                # Check list of lists (could be coordinate data)
                for i, item in enumerate(obj):
                    if isinstance(item, list) and 3 <= len(item) <= 12:
                        dimensions.add(len(item))
                        dimension_patterns.append(f"{path}[{i}][len={len(item)}]")
                    scan_for_dims(item, f"{path}[{i}]")
        
        scan_for_dims(data)
        
        return {
            'dimensions_present': sorted(dimensions),
            'dimension_patterns_count': len(dimension_patterns),
            'covers_3_to_12': all(d in dimensions for d in range(3, 13)),
            'sample_patterns': dimension_patterns[:10]  # First 10 patterns
        }
    
    def _analyze_training(self, data: dict, label: str) -> dict:
        """Analyze training information"""
        training = {
            'timestamp': data.get('timestamp'),
            'latent_dimension': data.get('latent_dim'),
            'version_hint': None,
            'complexity': 0
        }
        
        # Try to infer version from filename or data
        if 'v11' in label.lower():
            training['version_hint'] = 'v11'
        elif 'v2' in label.lower():
            training['version_hint'] = 'v2'
        
        # Estimate complexity
        total_size = len(json.dumps(data))
        training['complexity'] = total_size / 1000  # KB
        
        return training
    
    def _extract_dimensions_from_meta(self, meta_data: dict) -> dict:
        """Extract dimension information from metadata"""
        dimensions = set()
        patterns = []
        
        def scan(obj, path=""):
            if isinstance(obj, dict):
                for key, value in obj.items():
                    # Look for dimension indicators
                    key_str = str(key).lower()
                    if 'dim' in key_str or 'd' == key_str:
                        if isinstance(value, (int, float)) and 1 <= value <= 16:
                            dimensions.add(int(value))
                            patterns.append(f"{path}.{key}={value}")
                    
                    # Also check the value itself
                    if isinstance(value, (int, float)) and 3 <= value <= 12:
                        dimensions.add(int(value))
                        patterns.append(f"{path}.{key}[val={value}]")
                    
                    scan(value, f"{path}.{key}")
            
            elif isinstance(obj, list):
                # Check list lengths
                if 3 <= len(obj) <= 12:
                    dimensions.add(len(obj))
                    patterns.append(f"{path}[len={len(obj)}]")
                
                for i, item in enumerate(obj):
                    scan(item, f"{path}[{i}]")
        
        scan(meta_data)
        
        return {
            'dimensions': sorted(dimensions),
            'patterns': patterns[:20]  # First 20 patterns
        }
    
    def _deep_scan_geometric(self, obj, analysis: dict, current_path: str, depth: int):
        """Deep scan for geometric patterns"""
        analysis['max_nesting'] = max(analysis['max_nesting'], depth)
        
        if isinstance(obj, dict):
            for key, value in obj.items():
                key_str = str(key).lower()
                
                # Check for dimension layers
                if any(str(d) in key_str for d in range(3, 13)):
                    for d in range(3, 13):
                        if str(d) in key_str:
                            if d not in analysis['dimensional_layers']:
                                analysis['dimensional_layers'][d] = []
                            analysis['dimensional_layers'][d].append(f"{current_path}.{key}")
                
                # Count geometric entities
                if 'vector' in key_str:
                    analysis['geometric_entities']['vectors'] += 1
                elif 'matrix' in key_str:
                    analysis['geometric_entities']['matrices'] += 1
                elif 'tensor' in key_str:
                    analysis['geometric_entities']['tensors'] += 1
                elif 'rotation' in key_str:
                    analysis['geometric_entities']['rotations'] += 1
                elif 'quaternion' in key_str:
                    analysis['geometric_entities']['quaternions'] += 1
                elif 'coordinate' in key_str or 'coord' in key_str:
                    analysis['geometric_entities']['coordinates'] += 1
                elif 'warp' in key_str:
                    analysis['geometric_entities']['warp_operations'] += 1
                elif 'space' in key_str or 'spatial' in key_str:
                    analysis['geometric_entities']['spatial'] += 1
                
                self._deep_scan_geometric(value, analysis, f"{current_path}.{key}", depth + 1)
        
        elif isinstance(obj, list):
            # Check for geometric arrays
            if obj and all(isinstance(x, (int, float)) for x in obj):
                length = len(obj)
                if 3 <= length <= 12:
                    analysis['geometric_entities'][f'vector_{length}d'] += 1
            
            for i, item in enumerate(obj):
                self._deep_scan_geometric(item, analysis, f"{current_path}[{i}]", depth + 1)
    
    def _scan_for_operations(self, obj) -> list:
        """Scan for geometric operations"""
        operations = []
        
        def scan(obj, path=""):
            if isinstance(obj, dict):
                for key, value in obj.items():
                    key_str = str(key).lower()
                    # Geometric operations
                    ops = ['add', 'mult', 'prod', 'cross', 'dot', 'inner', 'outer', 
                          'transpose', 'inverse', 'transform', 'rotate', 'translate',
                          'scale', 'project', 'reflect', 'interpolate', 'extrude']
                    
                    for op in ops:
                        if op in key_str:
                            operations.append(f"{path}.{key}")
                            break
                    
                    scan(value, f"{path}.{key}")
        
        scan(obj)
        return operations
    
    def _find_dimensional_ops(self, obj) -> dict:
        """Find operations by dimension"""
        dim_ops = defaultdict(list)
        
        def scan(obj, path=""):
            if isinstance(obj, dict):
                for key, value in obj.items():
                    key_str = str(key)
                    # Check for dimension-specific operations
                    for d in range(3, 13):
                        dim_str = f"{d}d"
                        if dim_str in key_str.lower():
                            dim_ops[d].append(f"{path}.{key}")
                    
                    scan(value, f"{path}.{key}")
        
        scan(obj)
        return dict(dim_ops)
    
    def _find_warp_indicators(self, obj) -> list:
        """Find warp/spacetime indicators"""
        warp_keys = []
        
        def scan(obj, path=""):
            if isinstance(obj, dict):
                for key, value in obj.items():
                    key_str = str(key).lower()
                    warp_terms = ['warp', 'spacetime', 'space-time', 'relativity', 
                                 'lorentz', 'einstein', 'metric', 'curvature']
                    
                    for term in warp_terms:
                        if term in key_str:
                            warp_keys.append(f"{path}.{key}")
                            break
                    
                    scan(value, f"{path}.{key}")
        
        scan(obj)
        return warp_keys
    
    def _calculate_dict_depth(self, d: dict, current_depth: int = 0) -> int:
        """Calculate depth of nested dictionary"""
        if not isinstance(d, dict) or not d:
            return current_depth
        
        max_depth = current_depth
        for value in d.values():
            if isinstance(value, dict):
                max_depth = max(max_depth, self._calculate_dict_depth(value, current_depth + 1))
            elif isinstance(value, list):
                for item in value:
                    if isinstance(item, dict):
                        max_depth = max(max_depth, self._calculate_dict_depth(item, current_depth + 1))
        
        return max_depth
    
    def _count_total_elements(self, obj) -> int:
        """Count total elements in nested structure"""
        count = 0
        
        if isinstance(obj, dict):
            count += len(obj)
            for value in obj.values():
                count += self._count_total_elements(value)
        elif isinstance(obj, list):
            count += len(obj)
            for item in obj:
                count += self._count_total_elements(item)
        
        return count
    
    def _print_detailed_report(self, analysis: dict):
        """Print detailed analysis report"""
        label = analysis['label']
        summary = analysis['summary']
        
        print(f"\n📋 DETAILED REPORT: {label}")
        print(f"   File: {analysis['filename']}")
        print(f"   Total size: {summary['total_size']:,} characters")
        print(f"   Top-level keys: {', '.join(summary['top_keys'])}")
        
        if summary['timestamp']:
            print(f"   Timestamp: {summary['timestamp']}")
        if summary['latent_dim']:
            print(f"   Latent dimension: {summary['latent_dim']}")
        
        # Meta analysis
        meta = analysis['meta_analysis']
        print(f"\n🏛️  META/PANTHEON STRUCTURE:")
        print(f"   Type: {meta.get('type', 'Unknown')}")
        print(f"   Size: {meta.get('size_bytes', 0):,} bytes")
        print(f"   Depth: {meta.get('depth', 0)} levels")
        if 'dimensions_found' in meta and meta['dimensions_found']:
            print(f"   Dimensions in structure: {meta['dimensions_found']}")
        
        # Pantheon deep analysis
        pantheon = analysis['pantheon_analysis']
        if 'dimensional_layers' in pantheon and pantheon['dimensional_layers']:
            print(f"\n📐 DIMENSIONAL LAYERS FOUND:")
            for dim in sorted(pantheon['dimensional_layers'].keys()):
                layers = pantheon['dimensional_layers'][dim]
                print(f"   {dim}D: {len(layers)} layers")
        
        if 'geometric_entities' in pantheon and pantheon['geometric_entities']:
            print(f"\n🔷 GEOMETRIC ENTITIES:")
            for entity, count in sorted(pantheon['geometric_entities'].items()):
                print(f"   {entity}: {count}")
        
        # Commutator analysis
        comm = analysis['commutator_analysis']
        if comm.get('present'):
            print(f"\n🌀 HOLOGRAPHIC COMMUTATOR:")
            print(f"   Size: {comm.get('size', 0):,} bytes")
            print(f"   Structure: {comm.get('structure', 'Unknown')}")
            
            if comm.get('warp_indicators'):
                print(f"   Warp/spacetime indicators: {len(comm['warp_indicators'])} found")
            
            if comm.get('dimensional_operations'):
                print(f"   Dimension-specific operations:")
                for dim, ops in sorted(comm['dimensional_operations'].items()):
                    print(f"     {dim}D: {len(ops)} operations")
        
        # Dimensional analysis
        dims = analysis['dimensional_analysis']
        print(f"\n🎯 DIMENSIONAL COVERAGE ANALYSIS:")
        print(f"   Dimensions explicitly found: {dims['dimensions_present']}")
        print(f"   Covers 3D-12D completely: {dims['covers_3_to_12']}")
        print(f"   Dimension patterns found: {dims['dimension_patterns_count']}")
        
        # Training analysis
        train = analysis['training_analysis']
        print(f"\n⚙️  TRAINING METADATA:")
        print(f"   Version hint: {train.get('version_hint', 'Unknown')}")
        print(f"   Estimated complexity: {train.get('complexity', 0):.1f} KB")
        
        print(f"\n{'─' * 80}")
    
    def compare_models(self, label1: str, label2: str):
        """Compare two models comprehensively"""
        if label1 not in self.analyses or label2 not in self.analyses:
            print("Both models must be analyzed first!")
            return
        
        print(f"\n{'='*80}")
        print(f"COMPREHENSIVE COMPARISON: {label1} vs {label2}")
        print('='*80)
        
        a1 = self.analyses[label1]
        a2 = self.analyses[label2]
        
        # Compare key metrics
        print(f"\n📊 KEY METRICS COMPARISON:")
        metrics = [
            ('Total size', a1['summary']['total_size'], a2['summary']['total_size'], 'larger'),
            ('Structure depth', a1['meta_analysis'].get('depth', 0), a2['meta_analysis'].get('depth', 0), 'deeper'),
            ('Geometric entities', sum(a1['pantheon_analysis'].get('geometric_entities', {}).values()), 
             sum(a2['pantheon_analysis'].get('geometric_entities', {}).values()), 'more'),
            ('Has commutator', a1['summary']['has_commutator'], a2['summary']['has_commutator'], 'yes'),
        ]
        
        for name, val1, val2, better in metrics:
            diff = val1 - val2 if isinstance(val1, (int, float)) else None
            diff_str = ""
            if diff is not None:
                if diff > 0:
                    diff_str = f"(+{diff:,})"
                elif diff < 0:
                    diff_str = f"({diff:,})"
            
            print(f"   {name:20} {label1}: {val1} {diff_str:10} {label2}: {val2}")
        
        # Dimensional comparison
        print(f"\n📐 DIMENSIONAL CAPABILITIES:")
        dims1 = set(a1['dimensional_analysis']['dimensions_present'])
        dims2 = set(a2['dimensional_analysis']['dimensions_present'])
        
        all_dims = sorted(dims1.union(dims2))
        for dim in all_dims:
            has1 = "✓" if dim in dims1 else "✗"
            has2 = "✓" if dim in dims2 else "✗"
            print(f"   {dim:2}D:  {label1}: {has1}  {label2}: {has2}")
        
        # Check 3D-12D coverage
        target_dims = set(range(3, 13))
        covered1 = target_dims.intersection(dims1)
        covered2 = target_dims.intersection(dims2)
        
        print(f"\n🎯 3D-12D COVERAGE COMPLETENESS:")
        print(f"   {label1}: {len(covered1)}/{len(target_dims)} dimensions ({len(covered1)/len(target_dims)*100:.0f}%)")
        print(f"   {label2}: {len(covered2)}/{len(target_dims)} dimensions ({len(covered2)/len(target_dims)*100:.0f}%)")
        
        # Commutator comparison
        print(f"\n🌀 COMMUTATOR/WARP ANALYSIS:")
        comm1 = a1['commutator_analysis']
        comm2 = a2['commutator_analysis']
        
        if comm1.get('present') and comm2.get('present'):
            print(f"   Both have holographic commutator")
            print(f"   {label1} warp indicators: {len(comm1.get('warp_indicators', []))}")
            print(f"   {label2} warp indicators: {len(comm2.get('warp_indicators', []))}")
        elif comm1.get('present'):
            print(f"   Only {label1} has holographic commutator")
        elif comm2.get('present'):
            print(f"   Only {label2} has holographic commutator")
        
        # Geometric entity comparison
        print(f"\n🔷 GEOMETRIC ENTITY COMPARISON:")
        ents1 = a1['pantheon_analysis'].get('geometric_entities', {})
        ents2 = a2['pantheon_analysis'].get('geometric_entities', {})
        
        all_ents = set(ents1.keys()).union(set(ents2.keys()))
        for ent in sorted(all_ents):
            c1 = ents1.get(ent, 0)
            c2 = ents2.get(ent, 0)
            diff = c1 - c2
            arrow = "→" if diff == 0 else ("←" if diff > 0 else "→")
            print(f"   {ent:20} {label1}: {c1:3} {label2}: {c2:3} {arrow}")
        
        # Determine which is better
        print(f"\n{'='*80}")
        print(f"🎯 FINAL ASSESSMENT FOR GEOMETRIC TASKS:")
        
        score1 = self._calculate_true_geometric_score(a1)
        score2 = self._calculate_true_geometric_score(a2)
        
        print(f"\n   {label1} geometric capability score: {score1:.2f}/10.0")
        print(f"   {label2} geometric capability score: {score2:.2f}/10.0")
        
        if score1 > score2:
            print(f"\n   ✅ RECOMMENDATION: Use {label1} for geometric tasks")
            print(f"   Reason: Higher geometric capability score")
        elif score2 > score1:
            print(f"\n   ✅ RECOMMENDATION: Use {label2} for geometric tasks")
            print(f"   Reason: Higher geometric capability score")
        else:
            print(f"\n   ⚖️  RECOMMENDATION: Both are equally capable")
            print(f"   Choose based on specific needs")
        
        # Specific strengths
        print(f"\n💡 SPECIFIC STRENGTHS:")
        
        strengths1 = self._identify_strengths(a1, a2)
        strengths2 = self._identify_strengths(a2, a1)
        
        if strengths1:
            print(f"   {label1} excels in: {', '.join(strengths1[:3])}")
        if strengths2:
            print(f"   {label2} excels in: {', '.join(strengths2[:3])}")
    
    def _calculate_true_geometric_score(self, analysis: dict) -> float:
        """Calculate accurate geometric capability score"""
        score = 0.0
        
        # Dimensional coverage (3D-12D)
        dims = set(analysis['dimensional_analysis']['dimensions_present'])
        target_dims = set(range(3, 13))
        coverage = len(dims.intersection(target_dims))
        score += (coverage / len(target_dims)) * 4.0  # 40% of score
        
        # Geometric entities
        ents = analysis['pantheon_analysis'].get('geometric_entities', {})
        entity_score = sum(ents.values()) / 100  # Normalize
        score += min(entity_score, 3.0)  # 30% of score max
        
        # Structure complexity
        depth = analysis['meta_analysis'].get('depth', 0)
        score += min(depth / 3, 1.5)  # 15% of score max
        
        # Commutator presence
        if analysis['summary']['has_commutator']:
            score += 1.5  # 15% bonus
        
        # Size/completeness
        size = analysis['summary']['total_size']
        score += min(size / 2000000, 1.0)  # 10% of score max
        
        return min(score, 10.0)
    
    def _identify_strengths(self, analysis1: dict, analysis2: dict) -> list:
        """Identify what this model does better than the other"""
        strengths = []
        
        # Compare dimensional coverage
        dims1 = set(analysis1['dimensional_analysis']['dimensions_present'])
        dims2 = set(analysis2['dimensional_analysis']['dimensions_present'])
        extra_dims = dims1 - dims2
        if extra_dims:
            strengths.append(f"covers extra dimensions: {sorted(extra_dims)}")
        
        # Compare geometric entities
        ents1 = analysis1['pantheon_analysis'].get('geometric_entities', {})
        ents2 = analysis2['pantheon_analysis'].get('geometric_entities', {})
        
        for ent, count1 in ents1.items():
            count2 = ents2.get(ent, 0)
            if count1 > count2 + 10:  # Significant difference
                strengths.append(f"more {ent}")
        
        # Check for unique features
        if analysis1['summary']['has_commutator'] and not analysis2['summary']['has_commutator']:
            strengths.append("has holographic commutator")
        
        # Check size
        if analysis1['summary']['total_size'] > analysis2['summary']['total_size'] * 1.5:
            strengths.append("more detailed structure")
        
        return strengths

def main():
    print("EAMC GEOMETRIC MODEL COMPARISON TOOL")
    print("Designed for 3D-12D trained models with warp spacetime commutators")
    print("=" * 80)
    
    analyzer = EAMC_GeometricAnalyzer()
    
    # Analyze both files
    print("\nAnalyzing EAMC_v11...")
    analyzer.analyze_file("EAMC_weights_v11.json", "EAMC_v11")
    
    print("\nAnalyzing EAMC_v2...")
    analyzer.analyze_file("EAMC_weights_v2.json", "EAMC_v2")
    
    # Compare them
    analyzer.compare_models("EAMC_v11", "EAMC_v2")

if __name__ == "__main__":
    main()