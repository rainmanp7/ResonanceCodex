# Filename: Geometric_Holographic_Forge_V9.py
# PURPOSE: Forging the 3D-12D Pantheon using the "Sacred V9" Logic + Meta-Learner DNA.
#          Then training the Holographic Commutator.
# LOGIC: EXACT transplant of V9 (Oscillation, Phases, Rewards) into the Forge.
#        INCLUDES: Loading META_LEARNING_HOLOGRAPHIC.json for initialization.

import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import json
import time
import copy
from typing import Dict, List, Tuple

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"🚀 Running on {device}")

# Handling tqdm for progress bars
try:
    from tqdm import tqdm
except ImportError:
    def tqdm(iterable, desc=""):
        print(f"Starting: {desc}")
        return iterable

print("🔥 FORGING GEOMETRIC HOLOGRAPHIC SYSTEM (SACRED V9 + META-INIT)")
print("=" * 70)
print("🎯 Dimensions: 3-12")
print("🌌 Architecture: Sacred V9 Specialist + Universal Commutator")
print("📚 Initialization: Guided by META_LEARNING_HOLOGRAPHIC.json")
print("=" * 70)

# =============================================================================
# 0. LOAD METALEARNER KNOWLEDGE
# =============================================================================
def load_metalearner(filename="META_LEARNING_HOLOGRAPHIC.json"):
    print(f"📚 Loading Metalearner from {filename}...")
    try:
        with open(filename, 'r') as f:
            data = json.load(f)
        print(f"   ✅ Metalearner loaded!")
        return data
    except FileNotFoundError:
        print(f"   ❌ ERROR: {filename} not found. Specialists will be random (NOT V9 behavior).")
        return None

# =============================================================================
# 1. SACRED V9 DATA GENERATORS
# =============================================================================
def generate_euclidean_batch(batch_size, D, N):
    points = torch.randn(batch_size, N, D, device=device)
    distances = torch.norm(points, dim=2)
    labels = torch.argmin(distances, dim=1)
    return points, labels

def generate_curved_space_batch(batch_size, D, N, space_curvature=0.5):
    positions = torch.randn(batch_size, N, D, device=device) * 2
    base_metric = torch.eye(D, device=device).unsqueeze(0).repeat(batch_size, 1, 1)
    noise = torch.randn(batch_size, D, D, device=device) * space_curvature
    symmetric_noise = (noise + noise.transpose(1, 2)) / 2
    curvature_matrix = base_metric + symmetric_noise
    
    curved_positions = torch.bmm(positions, curvature_matrix)
    
    p_i = curved_positions.unsqueeze(2)
    p_j = curved_positions.unsqueeze(1)
    delta = p_i - p_j
    
    batch_size_val, N_val, _, D_val = delta.shape
    delta_reshaped = delta.reshape(batch_size_val * N_val * N_val, 1, D_val)
    curvature_matrix_expanded = curvature_matrix.repeat_interleave(N_val * N_val, dim=0)
    delta_transformed = torch.bmm(delta_reshaped, curvature_matrix_expanded).reshape(batch_size_val, N_val, N_val, D_val)
    
    dist_sq = torch.sum(delta * delta_transformed, dim=-1)
    dist_sq = dist_sq + torch.eye(N, device=device) * 1e9
    min_distances_per_sphere = torch.sqrt(torch.min(dist_sq, dim=2).values)
    labels = torch.argmax(min_distances_per_sphere, dim=1)
    
    centroid = torch.mean(curved_positions, dim=1, keepdim=True)
    final_input = curved_positions - centroid
    return final_input, labels

# =============================================================================
# 2. ARCHITECTURE
# =============================================================================

class HolographicCommutator(nn.Module):
    """The Universal Bridge from the Framework"""
    def __init__(self, feature_dim: int = 64, num_dims: int = 13):
        super().__init__()
        self.feature_dim = feature_dim
        self.dim_embedding = nn.Embedding(num_dims + 1, 16) 
        
        self.warp_engine = nn.Sequential(
            nn.Linear(64 + 16 + 16, 128),
            nn.ReLU(),
            nn.LayerNorm(128),
            nn.Linear(128, 128),
            nn.ReLU(),
            nn.Linear(128, 64) 
        )
        
    def transfer(self, knowledge: torch.Tensor, src_id: int, tgt_id: int) -> torch.Tensor:
        batch_size = knowledge.shape[0]
        src_emb = self.dim_embedding(torch.tensor([src_id], device=device))
        tgt_emb = self.dim_embedding(torch.tensor([tgt_id], device=device))
        src_emb = src_emb.expand(batch_size, -1)
        tgt_emb = tgt_emb.expand(batch_size, -1)
        combined = torch.cat([knowledge, src_emb, tgt_emb], dim=1)
        return self.warp_engine(combined)

class SacredV9Specialist(nn.Module):
    """
    The EXACT Model from V9 Experiment_3D_Metalearner.py
    Now correctly initialized with Meta-Learner data.
    """
    def __init__(self, D_in, N_in, metalearner_data, feature_dim=64, num_principles=3):
        super().__init__()
        self.D = D_in
        self.N = N_in
        self.feature_dim = feature_dim
        self.num_principles = num_principles
        
        # Base architecture
        self.feature_extractor = nn.Sequential(
            nn.Linear(self.D, 96),
            nn.ReLU(),
            nn.LayerNorm(96),
            nn.Linear(96, self.feature_dim),
            nn.ReLU()
        )
        
        # --- METALEARNER TRANSFER START ---
        if metalearner_data and str(D_in) in metalearner_data['meta_pantheon']:
            meta_state = metalearner_data['meta_pantheon'][str(D_in)]['state_dict']
            
            # Extract principle embeddings
            meta_principles = torch.tensor(meta_state['principle_embeddings'])
            self.principle_embeddings = nn.Parameter(meta_principles.clone())
            print(f"   🧠 Transferred principles from Metalearner for {D_in}D")
            
            # Extract principle weights
            meta_weights = torch.tensor(meta_state['principle_weights'])
            self.principle_rewards = nn.Parameter(torch.sigmoid(meta_weights), requires_grad=False)
            
            # Extract params
            self.learning_efficiency = torch.tensor(meta_state['learning_efficiency']).item()
            self.adaptation_speed = torch.tensor(meta_state['adaptation_speed']).item()
        else:
            print(f"   ⚠️ Warning: No Meta-data for {D_in}D. Random initialization.")
            self.principle_embeddings = nn.Parameter(torch.randn(num_principles, feature_dim))
            self.principle_rewards = nn.Parameter(torch.ones(num_principles) * 0.5, requires_grad=False)
            self.learning_efficiency = 1.0
            self.adaptation_speed = 1.0
        # --- METALEARNER TRANSFER END ---
        
        # Strategy selector
        self.strategy_selector = nn.Sequential(
            nn.Linear(self.feature_dim + num_principles, 48),
            nn.ReLU(),
            nn.Linear(48, num_principles),
            nn.Softmax(dim=-1)
        )
        
        self.scoring_head = nn.Linear(self.feature_dim, 1)

    def update_rewards(self, strategy_weights, accuracy, loss, acc_reward, loss_penalty):
        """Metalearner-modulated reward updates (V9 Logic)"""
        with torch.no_grad():
            learning_rate = 0.05 * self.adaptation_speed
            
            batch_reward = (accuracy * acc_reward) - (loss * loss_penalty)
            batch_reward = torch.clamp(torch.tensor(batch_reward, device=device), -1.0, 1.0)
            
            avg_usage = strategy_weights.mean(dim=0)
            for i in range(self.num_principles):
                if avg_usage[i] > 0.1:
                    current = self.principle_rewards[i]
                    self.principle_rewards[i] = (1 - learning_rate) * current + learning_rate * (batch_reward * avg_usage[i])

    def get_reward_context(self):
        return torch.sigmoid(self.principle_rewards * 3)
    
    def get_dynamic_penalties(self, epoch, stage):
        """V9 Logic: Dynamic Penalty Calculation"""
        base_acc_reward = 2.0
        base_loss_penalty = 0.5
        
        efficiency_factor = self.learning_efficiency
        
        if stage == "PUSH_TO_50":
            loss_penalty = base_loss_penalty * efficiency_factor
            acc_reward = base_acc_reward
        elif stage == "OSCILLATE_LOSS":
            loss_penalty = 1.5 * efficiency_factor * 1.2  
            acc_reward = 1.5
        else:  # OSCILLATE_ACCURACY
            loss_penalty = 0.3
            acc_reward = 2.5 * efficiency_factor
        
        return acc_reward, loss_penalty

    def forward(self, x, return_weights=False):
        batch_size, N, D = x.shape
        x_flat = x.view(-1, D)
        
        features = self.feature_extractor(x_flat)
        
        reward_ctx = self.get_reward_context().unsqueeze(0).repeat(features.shape[0], 1)
        features_with_ctx = torch.cat([features, reward_ctx], dim=1)
        
        strategy_weights = self.strategy_selector(features_with_ctx)
        
        historical_success = self.get_reward_context().unsqueeze(1)
        weighted_strategies = self.principle_embeddings * historical_success
        strategy_applied = torch.matmul(strategy_weights, weighted_strategies)
        
        enhanced_features = features + 0.1 * strategy_applied
        scores = self.scoring_head(enhanced_features)
        
        scores = scores.view(batch_size, N)
        
        if return_weights:
            return scores, strategy_weights
        return scores

# =============================================================================
# 3. TRAINING SYSTEM (THE FORGE)
# =============================================================================

class MetaLearningForge:
    def __init__(self):
        self.specialists = {}
        self.universal_commutator = HolographicCommutator(64).to(device)
        self.feature_dim = 64
        # Load the Metalearner Data ONCE at startup
        self.metalearner_data = load_metalearner()
    
    def train_specialist(self, dimension: int):
        """
        This is the V9 EXPERIMENT TRANSPLANTED.
        """
        print(f"\n{'='*60}")
        print(f"🔄 TRAINING SPECIALIST: DIMENSION {dimension}")
        print(f"{'='*60}")
        
        D = dimension
        N = 15
        BATCH_SIZE = 512
        
        # PASS METALEARNER DATA INTO MODEL
        model = SacredV9Specialist(D, N, self.metalearner_data).to(device)
        optimizer = optim.Adam(model.parameters(), lr=0.001)
        criterion = nn.CrossEntropyLoss()
        
        # Phase 1: Euclidean
        print(f"\n> [Phase 1] Euclidean Baseline (600 epochs)...")
        for epoch in range(600):
            inputs, labels = generate_euclidean_batch(BATCH_SIZE, D, N)
            optimizer.zero_grad()
            outputs, weights = model(inputs, return_weights=True)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()
            
            with torch.no_grad():
                pred = torch.max(outputs, 1)[1]
                acc = (pred == labels).float().mean().item()
                acc_rew, loss_pen = model.get_dynamic_penalties(epoch, "PUSH_TO_50")
                model.update_rewards(weights, acc, loss.item(), acc_rew, loss_pen)
            
            if (epoch + 1) % 50 == 0:
                print(f"  Epoch {epoch+1} | Loss: {loss.item():.4f} | Acc: {acc*100:.1f}%")
        
        # Phase 2: Gradual curvature warmup
        print(f"\n> [Phase 2] Curvature Warmup (0.1 → 0.6)...")
        for curvature in [0.1, 0.2, 0.3, 0.4, 0.5, 0.6]:
            print(f"  Curvature: {curvature:.1f}")
            for epoch in range(50):
                inputs, labels = generate_curved_space_batch(BATCH_SIZE, D, N, curvature)
                optimizer.zero_grad()
                outputs, weights = model(inputs, return_weights=True)
                loss = criterion(outputs, labels)
                loss.backward()
                optimizer.step()
                
                with torch.no_grad():
                    pred = torch.max(outputs, 1)[1]
                    acc = (pred == labels).float().mean().item()
                    acc_rew, loss_pen = model.get_dynamic_penalties(epoch, "PUSH_TO_50")
                    model.update_rewards(weights, acc, loss.item(), acc_rew, loss_pen)
        
        # Phase 3: Oscillating optimization
        print(f"\n> [Phase 3] V9 Oscillation Logic (curvature 0.5)...")
        
        best_loss = float('inf')
        best_acc = 0.0
        best_model_state = copy.deepcopy(model.state_dict())
        
        stage = "PUSH_TO_50"
        focus = "ACCURACY"
        check_cycle = 0
        epochs_no_improve = 0
        PATIENCE = 600
        
        recent_losses = []
        recent_accs = []
        
        for epoch in range(5000):
            inputs, labels = generate_curved_space_batch(BATCH_SIZE, D, N, 0.5)
            optimizer.zero_grad()
            outputs, weights = model(inputs, return_weights=True)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()
            
            with torch.no_grad():
                predictions = torch.max(outputs, 1)[1]
                accuracy = (predictions == labels).float().mean().item()
                
                if stage == "PUSH_TO_50":
                    acc_rew, loss_pen = model.get_dynamic_penalties(epoch, "PUSH_TO_50")
                elif focus == "LOSS":
                    acc_rew, loss_pen = model.get_dynamic_penalties(epoch, "OSCILLATE_LOSS")
                else:
                    acc_rew, loss_pen = model.get_dynamic_penalties(epoch, "OSCILLATE_ACCURACY")
                
                model.update_rewards(weights, accuracy, loss.item(), acc_rew, loss_pen)
            
            recent_losses.append(loss.item())
            recent_accs.append(accuracy)
            
            if (epoch + 1) % 2 == 0:
                check_cycle += 1
                avg_loss = np.mean(recent_losses[-2:])
                avg_acc = np.mean(recent_accs[-2:])
                
                if avg_acc > best_acc or (avg_acc >= best_acc and avg_loss < best_loss):
                    best_acc = avg_acc
                    best_loss = avg_loss
                    best_model_state = copy.deepcopy(model.state_dict())
                    epochs_no_improve = 0
                else:
                    epochs_no_improve += 1
                
                if stage == "PUSH_TO_50" and avg_acc >= 0.50:
                    print(f"  ✅ 50% Reached! Oscillation Starting...")
                    stage = "OSCILLATE"
                    focus = "LOSS"
                elif stage == "OSCILLATE" and check_cycle % 100 == 0:
                    focus = "ACCURACY" if focus == "LOSS" else "LOSS"
                    print(f"  🔄 Switching focus → {focus}")
                
                if check_cycle % 25 == 0:
                    status = f"[{stage}:{focus}]" if stage == "OSCILLATE" else f"[{stage}]"
                    print(f"  Epoch {epoch+1} {status} | Loss: {avg_loss:.4f} | Acc: {avg_acc*100:.1f}%")
                
                if epochs_no_improve >= PATIENCE:
                    print(f"\n  🛑 Converged at epoch {epoch+1}")
                    break
        
        if best_model_state: model.load_state_dict(best_model_state)
        self.specialists[dimension] = model
        print(f"   ✅ {dimension}D Ready | Final Loss: {best_loss:.4f} | Final Acc: {best_acc*100:.1f}%")
        return model
    
    def train_holographic_commutator(self, dimensions: List[int], max_steps: int = 20000, patience: int = 50):
        print(f"\n🌀 TRAINING HOLOGRAPHIC COMMUTATOR (The Universal Bridge)...")
        print(f"   Learning to map ANY dimension to ANY dimension using V9 Specialist Features.")
        
        optimizer = optim.Adam(self.universal_commutator.parameters(), lr=0.001)
        criterion = nn.MSELoss()
        
        best_loss = float('inf')
        best_state = None
        no_improve = 0
        
        COMM_BATCH = 64
        N = 15
        
        iterator = range(max_steps)
        try: iterator = tqdm(range(max_steps), desc="Forging Hologram")
        except: pass
        
        for step in iterator:
            src_dim = np.random.choice(dimensions)
            tgt_dim = np.random.choice(dimensions)
            if src_dim == tgt_dim: continue
            
            src_inputs, _ = generate_curved_space_batch(COMM_BATCH, src_dim, N, 0.5)
            tgt_inputs, _ = generate_curved_space_batch(COMM_BATCH, tgt_dim, N, 0.5)
            
            with torch.no_grad():
                src_flat = src_inputs.view(-1, src_dim)
                tgt_flat = tgt_inputs.view(-1, tgt_dim)
                src_feat = self.specialists[src_dim].feature_extractor(src_flat)
                tgt_feat = self.specialists[tgt_dim].feature_extractor(tgt_flat)
            
            warped_feat = self.universal_commutator.transfer(src_feat, src_dim, tgt_dim)
            
            optimizer.zero_grad()
            loss = criterion(warped_feat, tgt_feat)
            loss.backward()
            optimizer.step()
            
            if step % 100 == 0:
                curr_loss = loss.item()
                if hasattr(iterator, 'set_postfix'):
                    iterator.set_postfix({'loss': f'{curr_loss:.4f}'})
                    
                if curr_loss < best_loss - 1e-5:
                    best_loss = curr_loss
                    best_state = copy.deepcopy(self.universal_commutator.state_dict())
                    no_improve = 0
                else:
                    no_improve += 1
                
                if no_improve >= patience:
                    print(f"   🛑 Converged early at step {step}")
                    break
        
        if best_state:
            self.universal_commutator.load_state_dict(best_state)
        print(f"   ✅ Holographic Bridge Established | Best Loss: {best_loss:.4f}")

    def save_weights(self, filename: str = "SACRED_V9_HOLOGRAPHIC.json"):
        print(f"\n💾 SAVING HOLOGRAPHIC WEIGHTS...")
        
        def make_serializable(obj):
            if isinstance(obj, torch.Tensor): return obj.detach().cpu().numpy().tolist()
            if isinstance(obj, dict): return {k: make_serializable(v) for k, v in obj.items()}
            if isinstance(obj, list): return [make_serializable(i) for i in obj]
            return obj

        output_data = {
            'meta_pantheon': {},
            'holographic_commutator': {},
            'timestamp': time.time()
        }
        
        for dim, specialist in self.specialists.items():
            state_dict = {k: make_serializable(v) for k, v in specialist.state_dict().items()}
            # V9 specific metadata to save
            meta = {
                'principle_weights': specialist.principle_rewards,
                'learning_efficiency': specialist.learning_efficiency,
                'adaptation_speed': specialist.adaptation_speed
            }
            output_data['meta_pantheon'][str(dim)] = {'state_dict': state_dict, 'meta': make_serializable(meta)}
        
        comm_state = {k: make_serializable(v) for k, v in self.universal_commutator.state_dict().items()}
        output_data['holographic_commutator'] = comm_state
            
        with open(filename, 'w') as f:
            json.dump(output_data, f, indent=2)
        print(f"✅ File Saved: {filename}")

# =============================================================================
# EXECUTION
# =============================================================================

if __name__ == "__main__":
    forge = MetaLearningForge()
    
    # V9 works on 3D. We now expand this sacred logic to 3D-12D.
    dims = list(range(3, 13))
    
    # 1. Train Specialists (Sacred V9 Logic)
    for d in dims:
        forge.train_specialist(d)
        
    # 2. Train The One Bridge
    forge.train_holographic_commutator(dims, max_steps=45000, patience=50)
    
    # 3. Save
    forge.save_weights()
    
    print(f"\n{'='*70}")
    print("🎉 SACRED FORGE COMPLETE")
    print("   The V9 logic has been successfully applied to the full Pantheon.")