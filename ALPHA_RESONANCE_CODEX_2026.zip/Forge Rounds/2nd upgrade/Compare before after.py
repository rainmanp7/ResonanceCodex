# META_LEARNING_COMPARATOR_ULTIMATE.py
"""
THE JUDGEMENT OF THE FORGE (ULTIMATE)
1. Loads both 'META_LEARNING_HOLOGRAPHIC.json' and 'EAMC_INDUCED_HOLOGRAPHIC.json'.
2. Maps V9 variable names (scoring_head -> task_head) automatically.
3. Detects Architecture (Hidden 96 vs 128) automatically.
4. Uses shape-corrected Data Generation to ensure fair scoring.
"""

import torch
import torch.nn as nn
import numpy as np
import json
import os

print("⚖️  INITIATING HOLOGRAPHIC COMPARATOR (ULTIMATE)")
print("=" * 70)

# =============================================================================
# 1. SHARED ARCHITECTURE (DYNAMIC)
# =============================================================================

class HolographicCommutator(nn.Module):
    def __init__(self, feature_dim: int = 64, num_dims: int = 13):
        super().__init__()
        self.feature_dim = feature_dim
        self.dim_embedding = nn.Embedding(num_dims + 1, 16) 
        self.warp_engine = nn.Sequential(
            nn.Linear(64 + 16 + 16, 128),
            nn.ReLU(),
            nn.LayerNorm(128),
            nn.Linear(128, 128),
            nn.ReLU(),
            nn.Linear(128, 64)
        )
        
    def transfer(self, knowledge: torch.Tensor, src_id: int, tgt_id: int) -> torch.Tensor:
        batch_size = knowledge.shape[0]
        src_emb = self.dim_embedding(torch.tensor([src_id]))
        tgt_emb = self.dim_embedding(torch.tensor([tgt_id]))
        src_emb = src_emb.expand(batch_size, -1)
        tgt_emb = tgt_emb.expand(batch_size, -1)
        combined = torch.cat([knowledge, src_emb, tgt_emb], dim=1)
        return self.warp_engine(combined)

class DynamicSpecialist(nn.Module):
    def __init__(self, dimension: int, hidden_dim: int, strategy_dim: int, num_principles: int = 3):
        super().__init__()
        self.dimension = dimension
        self.feature_dim = 64 
        
        self.feature_extractor = nn.Sequential(
            nn.Linear(dimension, hidden_dim), 
            nn.ReLU(), 
            nn.LayerNorm(hidden_dim),
            nn.Linear(hidden_dim, self.feature_dim), 
            nn.ReLU()
        )
        
        self.principle_embeddings = nn.Parameter(torch.randn(num_principles, self.feature_dim))
        self.principle_weights = nn.Parameter(torch.ones(num_principles))
        
        # Dynamic Selector
        selector_out = 32 if strategy_dim == 64 else 48
        self.strategy_selector = nn.Sequential(
            nn.Linear(strategy_dim, selector_out),
            nn.ReLU(),
            nn.Linear(selector_out, num_principles), 
            nn.Softmax(dim=-1)
        )
        
        self.task_head = nn.Linear(self.feature_dim, 1)

    def forward(self, x):
        features = self.feature_extractor(x)
        
        input_size = self.strategy_selector[0].in_features
        
        if input_size > 64: # V9 Logic
            reward_ctx = torch.sigmoid(self.principle_weights * 3).unsqueeze(0).repeat(features.shape[0], 1)
            features_with_ctx = torch.cat([features, reward_ctx], dim=1)
            strategy_weights = self.strategy_selector(features_with_ctx)
            
            historical_success = reward_ctx[0].unsqueeze(1) 
            weighted_strategies = self.principle_embeddings * historical_success
            strategy_applied = torch.matmul(strategy_weights, weighted_strategies)
        else: # Original Logic
            strategy_weights = self.strategy_selector(features)
            strategy_applied = torch.matmul(strategy_weights, self.principle_embeddings)
            
        enhanced_features = features + 0.1 * strategy_applied
        return self.task_head(enhanced_features).squeeze(-1)

# =============================================================================
# 2. DATA GENERATOR (SHAPE CORRECTED)
# =============================================================================

def generate_test_batch(dimension: int, batch_size: int = 1000):
    inputs = torch.randn(batch_size, dimension)
    if dimension % 2 == 0: 
        targets = torch.sin(torch.sum(inputs, dim=1))
    else: 
        targets = torch.prod(inputs[:, :min(3, dimension)], dim=1)
    inputs += torch.randn_like(inputs) * 0.05
    
    # THIS IS THE FIX: No unsqueeze here because forward() does squeeze(-1)
    # Actually, let's align them.
    return inputs, targets # Returns (Batch)

# =============================================================================
# 3. LOADER
# =============================================================================

def load_system(filename):
    if not os.path.exists(filename):
        print(f"❌ {filename} NOT FOUND.")
        return None, None

    print(f"📂 Loading {filename}...")
    with open(filename, 'r') as f:
        weights = json.load(f)
    
    pantheon = {}
    
    for dim in range(3, 13):
        dim_str = str(dim)
        if dim_str in weights['meta_pantheon']:
            state_dict = weights['meta_pantheon'][dim_str]['state_dict']
            
            new_state_dict = {}
            for k, v in state_dict.items():
                tensor_v = torch.tensor(v)
                # MAP V9 NAMES TO STANDARD
                if 'scoring_head' in k: k = k.replace('scoring_head', 'task_head')
                if 'principle_rewards' in k: k = k.replace('principle_rewards', 'principle_weights')
                new_state_dict[k] = tensor_v
            
            hidden_dim = new_state_dict['feature_extractor.0.weight'].shape[0]
            strategy_in = new_state_dict['strategy_selector.0.weight'].shape[1]
            
            model = DynamicSpecialist(dim, hidden_dim, strategy_in)
            
            selector_hidden = new_state_dict['strategy_selector.0.weight'].shape[0]
            model.strategy_selector = nn.Sequential(
                nn.Linear(strategy_in, selector_hidden),
                nn.ReLU(),
                nn.Linear(selector_hidden, 3),
                nn.Softmax(dim=-1)
            )
            
            try:
                model.load_state_dict(new_state_dict, strict=False)
                pantheon[dim] = model
            except Exception as e:
                print(f"   ⚠️ Error loading {dim}D: {e}")

    commutator = HolographicCommutator(64)
    comm_state = weights['holographic_commutator']
    for k, v in comm_state.items():
        comm_state[k] = torch.tensor(v)
    commutator.load_state_dict(comm_state, strict=False)
    
    return pantheon, commutator

# =============================================================================
# 4. THE CONTEST
# =============================================================================

def compare():
    orig_pantheon, orig_comm = load_system("META_LEARNING_HOLOGRAPHIC.json")
    eamc_pantheon, eamc_comm = load_system("EAMC_INDUCED_HOLOGRAPHIC.json")
    
    if not orig_pantheon or not eamc_pantheon:
        print("CRITICAL: Missing files.")
        return

    print("\n" + "="*75)
    print(f"{'DIMENSION':<10} | {'ORIGINAL ACC':<15} | {'EAMC/V9 ACC':<15} | {'WINNER':<10}")
    print("="*75)
    
    total_orig_score = 0
    total_eamc_score = 0
    
    for dim in range(3, 13):
        inputs, targets = generate_test_batch(dim, 1000)
        
        with torch.no_grad():
            # Comparison
            out_orig = orig_pantheon[dim](inputs)
            # Targets is (Batch), Out is (Batch) - Broadcast safe
            acc_orig = ((out_orig - targets).abs() < 0.1).float().mean().item() * 100
            
            out_eamc = eamc_pantheon[dim](inputs)
            acc_eamc = ((out_eamc - targets).abs() < 0.1).float().mean().item() * 100
            
        winner = "ORIGINAL" if acc_orig > acc_eamc else "EAMC/V9"
        if abs(acc_orig - acc_eamc) < 0.5: winner = "TIE"
        
        if winner == "ORIGINAL": total_orig_score += 1
        if winner == "EAMC/V9": total_eamc_score += 1
        
        print(f"{dim}D Model  | {acc_orig:.2f}%          | {acc_eamc:.2f}%          | {winner}")

    print("-" * 75)
    
    print("\n🌀 TESTING HOLOGRAPHIC BRIDGE (Transfer Learning)...")
    bridge_score_orig = 0
    bridge_score_eamc = 0
    
    for _ in range(5): 
        src_dim = np.random.choice(range(3, 13))
        tgt_dim = np.random.choice(range(3, 13))
        if src_dim == tgt_dim: continue
        
        src_in, _ = generate_test_batch(src_dim, 500)
        tgt_in, _ = generate_test_batch(tgt_dim, 500)
        
        with torch.no_grad():
            s_feat_o = orig_pantheon[src_dim].feature_extractor(src_in)
            t_feat_o = orig_pantheon[tgt_dim].feature_extractor(tgt_in)
            warp_o = orig_comm.transfer(s_feat_o, src_dim, tgt_dim)
            loss_o = nn.MSELoss()(warp_o, t_feat_o).item()
            
            s_feat_e = eamc_pantheon[src_dim].feature_extractor(src_in)
            t_feat_e = eamc_pantheon[tgt_dim].feature_extractor(tgt_in)
            warp_e = eamc_comm.transfer(s_feat_e, src_dim, tgt_dim)
            loss_e = nn.MSELoss()(warp_e, t_feat_e).item()
            
            winner = "ORIGINAL" if loss_o < loss_e else "EAMC/V9"
            print(f"Bridge {src_dim}->{tgt_dim} | Loss: {loss_o:.4f}       | Loss: {loss_e:.4f}       | {winner}")
            
            if winner == "ORIGINAL": bridge_score_orig += 1
            else: bridge_score_eamc += 1

    print("="*75)
    print(f"🏆 FINAL SCORE: Original [{total_orig_score + bridge_score_orig}] vs EAMC/V9 [{total_eamc_score + bridge_score_eamc}]")
    
    if (total_eamc_score + bridge_score_eamc) > (total_orig_score + bridge_score_orig):
        print("🎉 VERDICT: The EAMC Induced Model is SUPERIOR.")
    else:
        print("⚠️ VERDICT: The Original Model is SUPERIOR.")

if __name__ == "__main__":
    compare()