# Filename: PantheonLogicForge_Emergent.py
# This is the definitive version with enhanced user feedback for Phase 1.
# It forges the E3 Logic Pantheon by training every dimension on all logic concepts.

import json
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import os
import time

# --- (SpecialistModel is unchanged and stable) ---
class SpecialistModel(nn.Module):
    def __init__(self, D_in, N_in):
        super(SpecialistModel, self).__init__()
        self.D = D_in
        self.N = N_in
        self.feature_extractor = nn.Sequential(nn.Linear(self.D, 96), nn.Sigmoid(), nn.LayerNorm(96), nn.Linear(96, 48), nn.Sigmoid())
        self.scoring_head = nn.Linear(48, 1)
        self.project_to_latent = nn.Linear(48, 16)
        self.project_from_latent = nn.Linear(16, 48)
    def forward(self, x):
        features = self.feature_extractor(x)
        scores = self.scoring_head(features).squeeze(-1)
        return scores

# --- Logic-Based Data Generators (unchanged) ---
def generate_simple_logic_batch(batch_size, D, N):
    points = torch.randn(batch_size, N, D); sums = torch.sum(points, dim=2); labels = torch.argmin(sums, dim=1)
    return points, labels

def generate_complex_logic_batch(batch_size, D, N, logic_type):
    if logic_type == 'Hierarchy':
        points = torch.rand(batch_size, N, D) * 2 - 1; apex_indices = torch.randint(0, N, (batch_size,)); points[torch.arange(batch_size), apex_indices, 0] += 5.0
        points += torch.randn(batch_size, N, D) * 0.5; labels = apex_indices; return points, labels
    elif logic_type == 'Causality':
        points = torch.zeros(batch_size, N, D); cause_indices = torch.randint(0, N, (batch_size,)); root_cause = torch.randn(batch_size, D) * 3
        points[torch.arange(batch_size), cause_indices] = root_cause; current_point = root_cause
        for i in range(1, N):
            effect = current_point * (0.95) + torch.randn(batch_size, D) * 0.5; points[torch.arange(batch_size), (cause_indices + i) % N] = effect; current_point = effect
        labels = cause_indices; return points, labels
    elif logic_type == 'Magnitude':
        points = torch.randn(batch_size, N, D); outlier_indices = torch.randint(0, N, (batch_size,)); outlier_points = torch.randn(batch_size, D) * 10
        points[torch.arange(batch_size), outlier_indices] = outlier_points; labels = outlier_indices; return points, labels
    elif logic_type == 'Sentiment':
        points = torch.randn(batch_size, N, D); sentiment_indices = torch.randint(0, N, (batch_size,)); points[torch.arange(batch_size), sentiment_indices, 1] *= 15
        labels = sentiment_indices; return points, labels
    elif logic_type == 'Spatial':
        return generate_curved_space_batch(batch_size, D, N)
    elif logic_type == 'Ethics':
        pattern = torch.linspace(-5, 5, N).unsqueeze(0).unsqueeze(-1).repeat(batch_size, 1, D); points = pattern + torch.randn(batch_size, N, D) * 0.3
        rule_breaker_indices = torch.randint(0, N, (batch_size,)); points[torch.arange(batch_size), rule_breaker_indices] += torch.randn(batch_size, D) * 5
        labels = rule_breaker_indices; return points, labels
    elif logic_type == 'Reality':
        points = torch.rand(batch_size, N, D) * 20 - 10; real_indices = torch.randint(0, N, (batch_size,))
        real_point = torch.ones(batch_size, D) * torch.randn(batch_size, 1) * 0.1; points[torch.arange(batch_size), real_indices] = real_point
        labels = real_indices; return points, labels
    else: raise ValueError(f"Unknown logic_type: {logic_type}")

def generate_curved_space_batch(batch_size, D, N, space_curvature=0.5):
    positions = torch.randn(batch_size, N, D) * 2; base_metric = torch.eye(D).unsqueeze(0).repeat(batch_size, 1, 1); noise = torch.randn(batch_size, D, D) * space_curvature
    symmetric_noise = (noise + noise.transpose(1, 2)) / 2; curvature_matrix = base_metric + symmetric_noise; curved_positions = torch.bmm(positions, curvature_matrix)
    p_i = curved_positions.unsqueeze(2); p_j = curved_positions.unsqueeze(1); delta = p_i - p_j; batch_size_val, N_val, _, D_val = delta.shape
    delta_reshaped = delta.reshape(batch_size_val * N_val * N_val, 1, D_val); curvature_matrix_expanded = curvature_matrix.repeat_interleave(N_val * N_val, dim=0)
    delta_transformed = torch.bmm(delta_reshaped, curvature_matrix_expanded).reshape(batch_size_val, N_val, N_val, D_val); dist_sq = torch.sum(delta * delta_transformed, dim=-1)
    dist_sq = dist_sq + torch.eye(N) * 1e9; min_distances_per_sphere = torch.sqrt(torch.min(dist_sq, dim=2).values); labels = torch.argmax(min_distances_per_sphere, dim=1)
    centroid = torch.mean(curved_positions, dim=1, keepdim=True); final_input = curved_positions - centroid; return final_input, labels

# --- The Worker Function for the Emergent Logic Curriculum ---
def train_and_save_worker(args):
    D, N, num_epochs_l1, num_epochs_l2, batch_size, pantheon_dict = args
    process_id = os.getpid()
    
    print(f"[{process_id}] Initializing {D}D Logic Generalist...")
    model = SpecialistModel(D, N); optimizer = optim.Adam(model.parameters(), lr=0.001); criterion = nn.CrossEntropyLoss()

    # --- LOGIC-TRAINING PHASE 1: THE SIMPLE RUN (E1) ---
    print(f"[{process_id}] Phase 1 (E1 - Simple Ordering) starting for {D}D Specialist...")
    for epoch in range(num_epochs_l1):
        inputs, labels = generate_simple_logic_batch(batch_size, D, N)
        optimizer.zero_grad(); outputs = model(inputs); loss = criterion(outputs, labels)
        loss.backward(); optimizer.step()

    # --- MODIFICATION: ADDED CONFIRMATION PRINTOUT FOR PHASE 1 ---
    with torch.no_grad():
        test_inputs, test_labels = generate_simple_logic_batch(1000, D, N)
        accuracy_l1 = (torch.max(model(test_inputs), 1)[1] == test_labels).sum().item() / 1000
    print(f"[{process_id}] Phase 1 (E1) for {D}D complete. Base Accuracy: {accuracy_l1*100:.2f}%")
    # --- END MODIFICATION ---

    # --- LOGIC-TRAINING PHASE 2: THE HIGHER RUN (E2) ---
    LOGIC_CURRICULUM = ['Spatial', 'Hierarchy', 'Ethics', 'Reality', 'Causality', 'Magnitude', 'Sentiment']
    print(f"[{process_id}] Phase 2 (E2 - Full Logic Curriculum) starting for {D}D Specialist...")
    best_loss = float('inf'); epochs_no_improve = 0; patience = 38; best_model_state_dict = model.state_dict()

    for epoch in range(num_epochs_l2):
        total_epoch_loss = 0.0
        for logic_type in LOGIC_CURRICULUM:
            inputs, labels = generate_complex_logic_batch(batch_size, D, N, logic_type)
            optimizer.zero_grad(); outputs = model(inputs); loss = criterion(outputs, labels)
            loss.backward(); optimizer.step()
            total_epoch_loss += loss.item()
        avg_epoch_loss = total_epoch_loss / len(LOGIC_CURRICULUM)
        if avg_epoch_loss < best_loss:
            best_loss = avg_epoch_loss; epochs_no_improve = 0; best_model_state_dict = model.state_dict()
        else: epochs_no_improve += 1
        if (epoch + 1) % 10 == 0: print(f"[{process_id}] E2 {D}D, Epoch {epoch+1}: Avg Loss: {avg_epoch_loss:.4f}, Best Loss: {best_loss:.4f}")
        if epochs_no_improve >= patience:
            print(f"[{process_id}] E2 {D}D: Early stopping at epoch {epoch+1}. Best avg loss: {best_loss:.4f}"); break
            
    print(f"[{process_id}] E2 {D}D: Loading best model for final evaluation.")
    model.load_state_dict(best_model_state_dict)
        
    final_accuracy = 0.0
    with torch.no_grad():
        for logic_type in LOGIC_CURRICULUM:
            test_inputs, test_labels = generate_complex_logic_batch(1000, D, N, logic_type)
            final_accuracy += (torch.max(model(test_inputs), 1)[1] == test_labels).sum().item() / 1000
    avg_accuracy = final_accuracy / len(LOGIC_CURRICULUM)
    print(f"[{process_id}] Phase 2 (E2) for {D}D Specialist complete. Final Average Accuracy: {avg_accuracy*100:.2f}%")

    # --- Save weights (unchanged) ---
    state_dict = model.state_dict(); weights_dict = { name: tensor.cpu().numpy().tolist() for name, tensor in state_dict.items() }
    final_weights = {
        "feature_extractor": { "W": [weights_dict['feature_extractor.0.weight'], weights_dict['feature_extractor.3.weight']], "b": [weights_dict['feature_extractor.0.bias'], weights_dict['feature_extractor.3.bias']] },
        "scoring_head": {"W": [weights_dict['scoring_head.weight']], "b": [weights_dict['scoring_head.bias']]},
        "project_to_latent": {"W": [weights_dict['project_to_latent.weight']], "b": [weights_dict['project_to_latent.bias']]},
        "project_from_latent": {"W": [weights_dict['project_from_latent.weight']], "b": [weights_dict['project_from_latent.bias']]}
    }
    specialist_data = { "dimensionality": D, "accuracy": avg_accuracy, "weights": final_weights }
    pantheon_dict[str(D)] = specialist_data
    print(f"[{process_id}] {D}D Logic Generalist weights prepared for saving.")

# --- Main Execution Block ---
if __name__ == "__main__":
    start_time = time.time(); pantheon_dict = {}; N_POINTS = 15; EPOCHS_L1 = 150; EPOCHS_L2 = 7000; BATCH_SIZE = 512; DIMENSIONS_TO_TRAIN = list(range(3, 13))
    tasks = [(D, N_POINTS, EPOCHS_L1, EPOCHS_L2, BATCH_SIZE, pantheon_dict) for D in DIMENSIONS_TO_TRAIN]
    
    print(f"--- Starting Emergent Logic Pantheon Forge ---")
    for task in tasks: train_and_save_worker(task)
        
    print("\n--- All logic training complete. Consolidating Logic Pantheon... ---")
    final_pantheon = {"latent_dim": 16, "pantheon": pantheon_dict}
    
    output_filename = 'EAMC_weights_v3_logic_emergent.json'
    with open(output_filename, 'w') as f: json.dump(final_pantheon, f, indent=4)
    total_time = time.time() - start_time
    print(f"\n✅ New Emergent Logic Pantheon forged and saved to {output_filename} in {total_time/60:.2f} minutes.")