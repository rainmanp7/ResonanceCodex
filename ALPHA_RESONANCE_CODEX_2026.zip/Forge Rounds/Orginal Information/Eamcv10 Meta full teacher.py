# Filename: Experiment_3D_Metalearner_FullControl.py
# PURPOSE: Metalearner has FULL CONTROL over training dynamics

import json
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import copy

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"🚀 Running on {device}")

# =============================================================================
# LOAD METALEARNER KNOWLEDGE
# =============================================================================
def load_metalearner(filename="META_LEARNING_HOLOGRAPHIC.json"):
    print(f"📚 Loading Metalearner from {filename}...")
    with open(filename, 'r') as f:
        data = json.load(f)
    print(f"   ✅ Metalearner loaded!")
    return data

# =============================================================================
# METALEARNER TRAINING CONTROLLER
# =============================================================================
class MetaLearnerController:
    """The AI that controls the training process"""
    def __init__(self, learning_efficiency, adaptation_speed):
        self.learning_efficiency = learning_efficiency
        self.adaptation_speed = adaptation_speed
        
        # Training state tracking
        self.loss_history = []
        self.acc_history = []
        self.current_stage = "PUSH_TO_50"
        self.current_focus = "ACCURACY"
        
        # Adaptive parameters
        self.oscillation_counter = 0
        self.cycles_since_switch = 0
        self.best_loss_seen = float('inf')
        self.best_acc_seen = 0.0
        
        # Consolidation mode
        self.consolidation_mode = False
        
        print(f"   🤖 MetaLearner Controller Initialized")
        print(f"      Learning Efficiency: {learning_efficiency:.3f}")
        print(f"      Adaptation Speed: {adaptation_speed:.3f}")
    
    def observe(self, loss, accuracy):
        """Metalearner observes current training state"""
        self.loss_history.append(loss)
        self.acc_history.append(accuracy)
        
        # Track bests
        if loss < self.best_loss_seen:
            self.best_loss_seen = loss
        if accuracy > self.best_acc_seen:
            self.best_acc_seen = accuracy
    
    def decide_learning_rate(self, base_lr=0.001):
        """Metalearner decides learning rate based on training dynamics"""
        if len(self.loss_history) < 20:
            return base_lr
        
        # Check recent improvement rate
        recent_losses = self.loss_history[-20:]
        improvement_rate = (recent_losses[0] - recent_losses[-1]) / 20
        
        # If improving well, keep current LR
        if improvement_rate > 0.01:
            return base_lr
        
        # If loss is very low (< 1.6), reduce LR to stabilize
        if recent_losses[-1] < 1.6:
            return base_lr * 0.3  # Much lower LR for fine-tuning
        
        # If stagnating, slightly reduce LR
        if abs(improvement_rate) < 0.001:
            return base_lr * 0.7
        
        return base_lr
    
    def should_switch_focus(self):
        """Metalearner decides when to switch oscillation focus"""
        self.cycles_since_switch += 1
        
        # Minimum time before considering switch
        if self.cycles_since_switch < 30:  # At least 60 epochs
            return False
        
        if len(self.loss_history) < 40:
            return False
        
        # Get recent trends (last 20 checks = 40 epochs)
        recent_loss = np.mean(self.loss_history[-20:])
        prev_loss = np.mean(self.loss_history[-40:-20])
        recent_acc = np.mean(self.acc_history[-20:])
        prev_acc = np.mean(self.acc_history[-40:-20])
        
        loss_improving = recent_loss < prev_loss
        acc_improving = recent_acc > prev_acc
        
        # Intelligent switching logic
        if self.current_focus == "LOSS":
            # If loss stopped improving but accuracy could grow, switch
            if not loss_improving and recent_acc < 0.60:
                print(f"      🧠 Metalearner: Loss plateaued, switching to ACCURACY")
                return True
            # If loss is very good (< 1.5), lock it in and boost accuracy
            if recent_loss < 1.5:
                print(f"      🧠 Metalearner: Loss excellent (<1.5), switching to ACCURACY")
                return True
            # Long time on loss focus without major improvement
            if self.cycles_since_switch > 150:  # 300 epochs
                print(f"      🧠 Metalearner: Long time on LOSS, trying ACCURACY")
                return True
        
        elif self.current_focus == "ACCURACY":
            # If accuracy stopped improving, go back to loss
            if not acc_improving:
                print(f"      🧠 Metalearner: Accuracy plateaued, switching to LOSS")
                return True
            # If accuracy is great but loss is drifting, tighten it
            if recent_acc > 0.56 and recent_loss > prev_loss:
                print(f"      🧠 Metalearner: Accuracy good but loss drifting, switching to LOSS")
                return True
            # Long time on accuracy without progress
            if self.cycles_since_switch > 150:
                print(f"      🧠 Metalearner: Long time on ACCURACY, trying LOSS")
                return True
        
        return False
    
    def get_penalties(self):
        """Metalearner determines optimal penalties based on current state"""
        if len(self.loss_history) == 0:
            return 2.0, 0.5
        
        recent_loss = np.mean(self.loss_history[-10:]) if len(self.loss_history) >= 10 else self.loss_history[-1]
        recent_acc = np.mean(self.acc_history[-10:]) if len(self.acc_history) >= 10 else self.acc_history[-1]
        
        # CONSOLIDATION MODE: Loss < 1.6 and Acc > 55%
        if recent_loss < 1.6 and recent_acc > 0.55:
            if not self.consolidation_mode:
                self.consolidation_mode = True
                print(f"      🎯 Metalearner: ENTERING CONSOLIDATION MODE")
            # Very gentle oscillation to fine-tune
            if self.current_focus == "LOSS":
                return 1.2, 1.0  # Moderate both
            else:
                return 2.0, 0.5  # Boost accuracy gently
        
        # STAGE 1: Push to 50%
        if self.current_stage == "PUSH_TO_50":
            # Prioritize accuracy heavily
            return 2.5 * self.learning_efficiency, 0.4
        
        # STAGE 2: Oscillating optimization
        if self.current_focus == "LOSS":
            # How aggressive should we be on loss?
            if recent_loss > 1.8:
                # Loss is high, crush it hard
                aggression = 2.0 * self.learning_efficiency
            elif recent_loss > 1.6:
                # Moderate loss, moderate pressure
                aggression = 1.5 * self.learning_efficiency
            else:
                # Loss is good, be gentle
                aggression = 1.0 * self.learning_efficiency
            
            return 1.2, aggression
        
        else:  # ACCURACY focus
            # How much should we boost accuracy?
            if recent_acc < 0.52:
                # Low accuracy, push hard
                boost = 3.0 * self.learning_efficiency
            elif recent_acc < 0.57:
                # Decent accuracy, moderate push
                boost = 2.5 * self.learning_efficiency
            else:
                # Good accuracy, gentle refinement
                boost = 2.0 * self.learning_efficiency
            
            return boost, 0.3
    
    def update_stage(self, avg_acc):
        """Update training stage"""
        if self.current_stage == "PUSH_TO_50" and avg_acc >= 0.50:
            self.current_stage = "OSCILLATE"
            self.current_focus = "LOSS"
            print(f"      ✅ Metalearner: 50% reached! Starting intelligent oscillation")
            return True
        return False
    
    def switch_focus(self):
        """Switch oscillation focus"""
        self.current_focus = "ACCURACY" if self.current_focus == "LOSS" else "LOSS"
        self.cycles_since_switch = 0
        self.oscillation_counter += 1

# =============================================================================
# ENHANCED SPECIALIST WITH FULL METALEARNER CONTROL
# =============================================================================
class MetaGuidedSpecialist(nn.Module):
    def __init__(self, D_in, N_in, metalearner_data, feature_dim=64, num_principles=3):
        super().__init__()
        self.D = D_in
        self.N = N_in
        self.feature_dim = feature_dim
        self.num_principles = num_principles
        
        self.feature_extractor = nn.Sequential(
            nn.Linear(self.D, 96),
            nn.ReLU(),
            nn.LayerNorm(96),
            nn.Linear(96, self.feature_dim),
            nn.ReLU()
        )
        
        # METALEARNER TRANSFER
        meta_state = metalearner_data['meta_pantheon'][str(D_in)]['state_dict']
        
        meta_principles = torch.tensor(meta_state['principle_embeddings'])
        self.principle_embeddings = nn.Parameter(meta_principles.clone())
        print(f"   🧠 Transferred principle embeddings from metalearner!")
        
        meta_weights = torch.tensor(meta_state['principle_weights'])
        self.principle_rewards = nn.Parameter(torch.sigmoid(meta_weights), requires_grad=False)
        print(f"   🎯 Initialized rewards: {self.principle_rewards.data}")
        
        self.learning_efficiency = torch.tensor(meta_state['learning_efficiency']).item()
        self.adaptation_speed = torch.tensor(meta_state['adaptation_speed']).item()
        
        self.strategy_selector = nn.Sequential(
            nn.Linear(self.feature_dim + num_principles, 48),
            nn.ReLU(),
            nn.Linear(48, num_principles),
            nn.Softmax(dim=-1)
        )
        
        self.scoring_head = nn.Linear(self.feature_dim, 1)
        
        # Create controller
        self.controller = MetaLearnerController(self.learning_efficiency, self.adaptation_speed)

    def update_rewards(self, strategy_weights, accuracy, loss, acc_reward, loss_penalty):
        """Fast adaptive reward updates"""
        with torch.no_grad():
            # Use metalearner's adaptation_speed
            learning_rate = 0.08 * self.adaptation_speed
            
            batch_reward = (accuracy * acc_reward) - (loss * loss_penalty)
            batch_reward = torch.clamp(torch.tensor(batch_reward, device=device), -1.0, 1.0)
            
            avg_usage = strategy_weights.mean(dim=0)
            for i in range(self.num_principles):
                if avg_usage[i] > 0.1:
                    current = self.principle_rewards[i]
                    self.principle_rewards[i] = (1 - learning_rate) * current + learning_rate * (batch_reward * avg_usage[i])

    def get_reward_context(self):
        return torch.sigmoid(self.principle_rewards * 3)

    def forward(self, x, return_weights=False):
        batch_size, N, D = x.shape
        x_flat = x.view(-1, D)
        
        features = self.feature_extractor(x_flat)
        
        reward_ctx = self.get_reward_context().unsqueeze(0).repeat(features.shape[0], 1)
        features_with_ctx = torch.cat([features, reward_ctx], dim=1)
        
        strategy_weights = self.strategy_selector(features_with_ctx)
        
        historical_success = self.get_reward_context().unsqueeze(1)
        weighted_strategies = self.principle_embeddings * historical_success
        strategy_applied = torch.matmul(strategy_weights, weighted_strategies)
        
        enhanced_features = features + 0.1 * strategy_applied
        scores = self.scoring_head(enhanced_features)
        
        scores = scores.view(batch_size, N)
        
        if return_weights:
            return scores, strategy_weights
        return scores

# =============================================================================
# DATA GENERATORS
# =============================================================================
def generate_euclidean_batch(batch_size, D, N):
    points = torch.randn(batch_size, N, D, device=device)
    distances = torch.norm(points, dim=2)
    labels = torch.argmin(distances, dim=1)
    return points, labels

def generate_curved_space_batch(batch_size, D, N, space_curvature=0.5):
    positions = torch.randn(batch_size, N, D, device=device) * 2
    base_metric = torch.eye(D, device=device).unsqueeze(0).repeat(batch_size, 1, 1)
    noise = torch.randn(batch_size, D, D, device=device) * space_curvature
    symmetric_noise = (noise + noise.transpose(1, 2)) / 2
    curvature_matrix = base_metric + symmetric_noise
    
    curved_positions = torch.bmm(positions, curvature_matrix)
    
    p_i = curved_positions.unsqueeze(2)
    p_j = curved_positions.unsqueeze(1)
    delta = p_i - p_j
    
    batch_size_val, N_val, _, D_val = delta.shape
    delta_reshaped = delta.reshape(batch_size_val * N_val * N_val, 1, D_val)
    curvature_matrix_expanded = curvature_matrix.repeat_interleave(N_val * N_val, dim=0)
    delta_transformed = torch.bmm(delta_reshaped, curvature_matrix_expanded).reshape(batch_size_val, N_val, N_val, D_val)
    
    dist_sq = torch.sum(delta * delta_transformed, dim=-1)
    dist_sq = dist_sq + torch.eye(N, device=device) * 1e9
    min_distances_per_sphere = torch.sqrt(torch.min(dist_sq, dim=2).values)
    labels = torch.argmax(min_distances_per_sphere, dim=1)
    
    centroid = torch.mean(curved_positions, dim=1, keepdim=True)
    final_input = curved_positions - centroid
    return final_input, labels

# =============================================================================
# TRAINING WITH FULL METALEARNER CONTROL
# =============================================================================
def train_3d_with_metalearner():
    D = 3
    N = 15
    BATCH_SIZE = 512
    
    metalearner_data = load_metalearner()
    
    print(f"\n{'='*60}")
    print(f"🤖 METALEARNER FULL CONTROL MODE")
    print(f"{'='*60}")
    
    model = MetaGuidedSpecialist(D, N, metalearner_data).to(device)
    optimizer = optim.Adam(model.parameters(), lr=0.001)
    criterion = nn.CrossEntropyLoss()
    
    # Phase 1: Euclidean
    print(f"\n> [Phase 1] Euclidean Baseline...")
    for epoch in range(200):
        inputs, labels = generate_euclidean_batch(BATCH_SIZE, D, N)
        optimizer.zero_grad()
        outputs, weights = model(inputs, return_weights=True)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()
        
        with torch.no_grad():
            pred = torch.max(outputs, 1)[1]
            acc = (pred == labels).float().mean().item()
            acc_rew, loss_pen = model.controller.get_penalties()
            model.update_rewards(weights, acc, loss.item(), acc_rew, loss_pen)
        
        if (epoch + 1) % 50 == 0:
            print(f"  Epoch {epoch+1} | Loss: {loss.item():.4f} | Acc: {acc*100:.1f}%")
    
    # Phase 2: Curvature warmup
    print(f"\n> [Phase 2] Curvature Warmup...")
    for curvature in [0.1, 0.2, 0.3, 0.4, 0.5, 0.6]:
        print(f"  Curvature: {curvature:.1f}")
        for epoch in range(50):
            inputs, labels = generate_curved_space_batch(BATCH_SIZE, D, N, curvature)
            optimizer.zero_grad()
            outputs, weights = model(inputs, return_weights=True)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()
            
            with torch.no_grad():
                pred = torch.max(outputs, 1)[1]
                acc = (pred == labels).float().mean().item()
                acc_rew, loss_pen = model.controller.get_penalties()
                model.update_rewards(weights, acc, loss.item(), acc_rew, loss_pen)
    
    # Phase 3: Metalearner takes full control
    print(f"\n> [Phase 3] METALEARNER FULL CONTROL...")
    print(f"   The AI is now driving all training decisions\n")
    
    best_loss = float('inf')
    best_acc = 0.0
    best_model_state = copy.deepcopy(model.state_dict())
    
    check_cycle = 0
    epochs_no_improve = 0
    PATIENCE = 800
    
    recent_losses = []
    recent_accs = []
    
    for epoch in range(10000):
        # Metalearner decides learning rate
        current_lr = model.controller.decide_learning_rate()
        for param_group in optimizer.param_groups:
            param_group['lr'] = current_lr
        
        inputs, labels = generate_curved_space_batch(BATCH_SIZE, D, N, 0.5)
        optimizer.zero_grad()
        outputs, weights = model(inputs, return_weights=True)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()
        
        with torch.no_grad():
            predictions = torch.max(outputs, 1)[1]
            accuracy = (predictions == labels).float().mean().item()
            
            # Metalearner decides penalties
            acc_rew, loss_pen = model.controller.get_penalties()
            model.update_rewards(weights, accuracy, loss.item(), acc_rew, loss_pen)
        
        recent_losses.append(loss.item())
        recent_accs.append(accuracy)
        
        # Every 2 epochs
        if (epoch + 1) % 2 == 0:
            check_cycle += 1
            avg_loss = np.mean(recent_losses[-2:])
            avg_acc = np.mean(recent_accs[-2:])
            
            # Metalearner observes
            model.controller.observe(avg_loss, avg_acc)
            
            if avg_acc > best_acc or (avg_acc >= best_acc and avg_loss < best_loss):
                best_acc = avg_acc
                best_loss = avg_loss
                best_model_state = copy.deepcopy(model.state_dict())
                epochs_no_improve = 0
            else:
                epochs_no_improve += 1
            
            # Stage transitions
            model.controller.update_stage(avg_acc)
            
            # Metalearner decides when to switch
            if model.controller.current_stage == "OSCILLATE" and model.controller.should_switch_focus():
                model.controller.switch_focus()
            
            # Logging
            if check_cycle % 25 == 0:
                stage = model.controller.current_stage
                focus = model.controller.current_focus
                status = f"[{stage}:{focus}]" if stage == "OSCILLATE" else f"[{stage}]"
                consol = " 🎯CONSOLIDATING" if model.controller.consolidation_mode else ""
                print(f"  Epoch {epoch+1} {status}{consol} | Loss: {avg_loss:.4f} | Acc: {avg_acc*100:.1f}% | LR: {current_lr:.6f}")
            
            if epochs_no_improve >= PATIENCE:
                print(f"\n  🛑 Metalearner: Convergence achieved at epoch {epoch+1}")
                break
    
    model.load_state_dict(best_model_state)
    
    # Final validation
    with torch.no_grad():
        test_inputs, test_labels = generate_curved_space_batch(1000, D, N)
        outputs = model(test_inputs)
        final_acc = (torch.max(outputs, 1)[1] == test_labels).sum().item() / 1000
    
    print(f"\n{'='*60}")
    print(f"🏁 METALEARNER FULL CONTROL COMPLETE")
    print(f"{'='*60}")
    print(f"Best Training Loss: {best_loss:.4f}")
    print(f"Best Training Acc:  {best_acc*100:.2f}%")
    print(f"Final Validation:   {final_acc*100:.2f}%")
    print(f"Oscillations Made:  {model.controller.oscillation_counter}")
    print(f"{'='*60}")

if __name__ == "__main__":
    train_3d_with_metalearner()