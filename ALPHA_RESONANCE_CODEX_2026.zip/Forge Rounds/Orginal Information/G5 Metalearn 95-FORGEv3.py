# Filename: PantheonForge_Meta_Curriculum.py
# This script implements the definitive Meta-Learning as a two-stage curriculum.
# It forges the E2 Pantheon by training each specialist sequentially,
# first on a simple task (E1), then adapting it to a complex task (E2).

import json
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import os
import time

# --- (SpecialistModel, the "Metalearner", is unchanged and stable) ---
class SpecialistModel(nn.Module):
    def __init__(self, D_in, N_in):
        super(SpecialistModel, self).__init__()
        self.D = D_in
        self.N = N_in
        self.feature_extractor = nn.Sequential(nn.Linear(self.D, 96), nn.Sigmoid(), nn.LayerNorm(96), nn.Linear(96, 48), nn.Sigmoid())
        self.scoring_head = nn.Linear(48, 1)
        self.project_to_latent = nn.Linear(48, 16) # Part of the Commutator
        self.project_from_latent = nn.Linear(16, 48) # Part of the Commutator
    def forward(self, x):
        features = self.feature_extractor(x)
        scores = self.scoring_head(features).squeeze(-1)
        return scores

# --- (Data Generators are verified and stable) ---
def generate_euclidean_batch(batch_size, D, N):
    # Data for the "First, Simple Run" (E1)
    points = torch.randn(batch_size, N, D)
    distances = torch.norm(points, dim=2)
    labels = torch.argmin(distances, dim=1)
    return points, labels

def generate_curved_space_batch(batch_size, D, N, space_curvature=0.5):
    # Data for the "Second, Higher Run" (E2)
    positions = torch.randn(batch_size, N, D) * 2
    base_metric = torch.eye(D).unsqueeze(0).repeat(batch_size, 1, 1)
    noise = torch.randn(batch_size, D, D) * space_curvature
    symmetric_noise = (noise + noise.transpose(1, 2)) / 2
    curvature_matrix = base_metric + symmetric_noise
    curved_positions = torch.bmm(positions, curvature_matrix)
    p_i = curved_positions.unsqueeze(2); p_j = curved_positions.unsqueeze(1); delta = p_i - p_j
    batch_size_val, N_val, _, D_val = delta.shape
    delta_reshaped = delta.reshape(batch_size_val * N_val * N_val, 1, D_val)
    curvature_matrix_expanded = curvature_matrix.repeat_interleave(N_val * N_val, dim=0)
    delta_transformed = torch.bmm(delta_reshaped, curvature_matrix_expanded).reshape(batch_size_val, N_val, N_val, D_val)
    dist_sq = torch.sum(delta * delta_transformed, dim=-1)
    dist_sq = dist_sq + torch.eye(N) * 1e9
    min_distances_per_sphere = torch.sqrt(torch.min(dist_sq, dim=2).values)
    labels = torch.argmax(min_distances_per_sphere, dim=1)
    centroid = torch.mean(curved_positions, dim=1, keepdim=True)
    final_input = curved_positions - centroid
    return final_input, labels

# --- The Worker Function for the Meta-Learning Curriculum ---
def train_and_save_worker(args):
    D, N, num_epochs_l1, num_epochs_l2, batch_size, pantheon_dict = args
    process_id = os.getpid()
    
    model = SpecialistModel(D, N) # Initialize the "Metalearner"
    optimizer = optim.Adam(model.parameters(), lr=0.001)
    criterion = nn.CrossEntropyLoss()

    # --- META-TRAINING PHASE 1: THE SIMPLE RUN (E1) ---
    print(f"[{process_id}] Meta-Phase 1 (E1) starting for {D}D Metalearner...")
    for epoch in range(num_epochs_l1):
        inputs, labels = generate_euclidean_batch(batch_size, D, N)
        optimizer.zero_grad(); outputs = model(inputs); loss = criterion(outputs, labels)
        loss.backward(); optimizer.step()
    
    with torch.no_grad():
        test_inputs, test_labels = generate_euclidean_batch(1000, D, N)
        accuracy_l1 = (torch.max(model(test_inputs), 1)[1] == test_labels).sum().item() / 1000
    print(f"[{process_id}] Meta-Phase 1 (E1) for {D}D complete. Accuracy: {accuracy_l1*100:.2f}%")

    if accuracy_l1 < 0.8:
        print(f"[{process_id}] WARNING: Phase 1 training for {D}D failed. Aborting.")
        return

    # --- META-TRAINING PHASE 2: THE HIGHER RUN (E2 ADAPTATION) ---
    print(f"[{process_id}] Meta-Phase 2 (E2) starting for {D}D Metalearner...")
    best_loss = float('inf')
    epochs_no_improve = 0
    patience = 95
    best_model_state_dict = model.state_dict()

    for epoch in range(num_epochs_l2):
        inputs, labels = generate_curved_space_batch(batch_size, D, N)
        optimizer.zero_grad(); outputs = model(inputs); loss = criterion(outputs, labels)
        loss.backward(); optimizer.step()
        
        if loss.item() < best_loss:
            best_loss = loss.item()
            epochs_no_improve = 0
            best_model_state_dict = model.state_dict()
        else:
            epochs_no_improve += 1
        
        if epochs_no_improve >= patience:
            print(f"[{process_id}] E2 {D}D: Early stopping triggered at epoch {epoch+1}. Best loss: {best_loss:.4f}")
            break
            
    print(f"[{process_id}] E2 {D}D: Loading best model weights for final evaluation.")
    model.load_state_dict(best_model_state_dict)
        
    with torch.no_grad():
        test_inputs, test_labels = generate_curved_space_batch(1000, D, N)
        accuracy_l2 = (torch.max(model(test_inputs), 1)[1] == test_labels).sum().item() / 1000
    print(f"[{process_id}] Meta-Phase 2 (E2) for {D}D complete. Final Accuracy: {accuracy_l2*100:.2f}%")

    # --- Save weights in the required, unchanged format ---
    state_dict = model.state_dict()
    weights_dict = { name: tensor.cpu().numpy().tolist() for name, tensor in state_dict.items() }
    final_weights = {
        "feature_extractor": { "W": [weights_dict['feature_extractor.0.weight'], weights_dict['feature_extractor.3.weight']], "b": [weights_dict['feature_extractor.0.bias'], weights_dict['feature_extractor.3.bias']] },
        "scoring_head": {"W": [weights_dict['scoring_head.weight']], "b": [weights_dict['scoring_head.bias']]},
        "project_to_latent": {"W": [weights_dict['project_to_latent.weight']], "b": [weights_dict['project_to_latent.bias']]},
        "project_from_latent": {"W": [weights_dict['project_from_latent.weight']], "b": [weights_dict['project_from_latent.bias']]}
    }
    specialist_data = { "dimensionality": D, "accuracy": accuracy_l2, "weights": final_weights }
    pantheon_dict[str(D)] = specialist_data
    print(f"[{process_id}] {D}D Metalearner weights prepared for saving.")

# --- Main Execution Block ---
if __name__ == "__main__":
    start_time = time.time()
    pantheon_dict = {}
    
    # Training Parameters
    N_POINTS = 15
    EPOCHS_L1 = 250    # Epochs for the "simple run"
    EPOCHS_L2 = 7000   # Max epochs for the "higher run"
    BATCH_SIZE = 512
    DIMENSIONS_TO_TRAIN = list(range(3, 13))

    tasks = [(D, N_POINTS, EPOCHS_L1, EPOCHS_L2, BATCH_SIZE, pantheon_dict) for D in DIMENSIONS_TO_TRAIN]
    
    print(f"Starting Meta-Learning Curriculum for dimensions {DIMENSIONS_TO_TRAIN}...")
    for task in tasks:
        train_and_save_worker(task)
        
    print("\n--- All training complete. Consolidating Pantheon... ---")
    final_pantheon = {"latent_dim": 16, "pantheon": pantheon_dict}
    
    output_filename = 'EAMC_Metav3.json'
    
    with open(output_filename, 'w') as f:
        json.dump(final_pantheon, f, indent=4)

    total_time = time.time() - start_time
    print(f"\n✅ New Pantheon forged via Meta-Learning Curriculum and saved to {output_filename} in {total_time/60:.2f} minutes.")