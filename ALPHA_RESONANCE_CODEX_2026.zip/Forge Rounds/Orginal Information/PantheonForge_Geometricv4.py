# Filename: PantheonMetaForge_Geometric_Verbose.py
# PURPOSE: To forge an advanced, self-contained system for solving a complex
#          GEOMETRIC problem. This system is a peer to, but separate from,
#          any other meta-learning systems.
#
# ARCHITECTURE:
#   - Specialists: Each specialist learns to solve the geometric task in its
#     own dimension using a meta-learning approach (learning to combine a
#     set of "first principles").
#   - Commutator: A single "holographic" network learns the universal rules
#     for translating geometric "thoughts" between any two dimensions.

import json
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import time
import copy
from typing import List, Dict, Tuple

# Use tqdm for progress bars if available, otherwise provide a dummy function
try:
    from tqdm import tqdm
except ImportError:
    print("WARNING: tqdm not found. Progress bars will be disabled. `pip install tqdm` to enable.")
    def tqdm(iterable, desc=""):
        print(f"--- Starting Task: {desc} ---")
        return iterable

# =============================================================================
# 1. BANNER
# =============================================================================
print("=" * 80)
print("🔥🔥🔥 PANTHEON META-FORGE (GEOMETRIC DOMAIN) - v2.0 Verbose 🔥🔥🔥")
print("=" * 80)
print("This script will now build a complete, high-performance system for GEOMETRY.")
print("It is composed of two primary components:")
print("  1. A 'Pantheon' of META-LEARNING SPECIALISTS, one for each dimension.")
print("  2. A single HOLOGRAPHIC COMMUTATOR to act as a universal translator between them.")
print("-" * 80)


# =============================================================================
# 2. DATA GENERATORS (Verified and Stable)
# =============================================================================
# These functions generate the specific geometric problems our system will solve.

def generate_euclidean_batch(batch_size, D, N):
    points = torch.randn(batch_size, N, D)
    distances = torch.norm(points, dim=2)
    labels = torch.argmin(distances, dim=1)
    return points, labels

def generate_curved_space_batch(batch_size, D, N, space_curvature=0.5):
    positions = torch.randn(batch_size, N, D) * 2
    base_metric = torch.eye(D).unsqueeze(0).repeat(batch_size, 1, 1)
    noise = torch.randn(batch_size, D, D) * space_curvature
    symmetric_noise = (noise + noise.transpose(1, 2)) / 2
    curvature_matrix = base_metric + symmetric_noise
    curved_positions = torch.bmm(positions, curvature_matrix)
    p_i = curved_positions.unsqueeze(2); p_j = curved_positions.unsqueeze(1); delta = p_i - p_j
    batch_size_val, N_val, _, D_val = delta.shape
    delta_reshaped = delta.reshape(batch_size_val * N_val * N_val, 1, D_val)
    curvature_matrix_expanded = curvature_matrix.repeat_interleave(N_val * N_val, dim=0)
    delta_transformed = torch.bmm(delta_reshaped, curvature_matrix_expanded).reshape(batch_size_val, N_val, N_val, D_val)
    dist_sq = torch.sum(delta * delta_transformed, dim=-1)
    dist_sq = dist_sq + torch.eye(N) * 1e9
    min_distances_per_sphere = torch.sqrt(torch.min(dist_sq, dim=2).values)
    labels = torch.argmax(min_distances_per_sphere, dim=1)
    centroid = torch.mean(curved_positions, dim=1, keepdim=True)
    final_input = curved_positions - centroid
    return final_input, labels


# =============================================================================
# 3. ADVANCED ARCHITECTURE
# =============================================================================

class HolographicCommutator(nn.Module):
    """ The Universal Translator for Geometric Concepts. """
    def __init__(self, feature_dim: int = 64, num_dims: int = 13):
        super().__init__()
        self.feature_dim = feature_dim
        self.dim_embedding = nn.Embedding(num_dims + 1, 16)
        self.warp_engine = nn.Sequential(
            nn.Linear(feature_dim + 16 + 16, 128), nn.ReLU(), nn.LayerNorm(128),
            nn.Linear(128, 128), nn.ReLU(),
            nn.Linear(128, feature_dim)
        )

    def transfer(self, knowledge: torch.Tensor, src_id: int, tgt_id: int) -> torch.Tensor:
        batch_size = knowledge.shape[0]
        device = knowledge.device
        src_emb = self.dim_embedding(torch.tensor([src_id], device=device)).expand(batch_size, -1)
        tgt_emb = self.dim_embedding(torch.tensor([tgt_id], device=device)).expand(batch_size, -1)
        combined = torch.cat([knowledge, src_emb, tgt_emb], dim=1)
        return self.warp_engine(combined)

class GeometricMetaSpecialist(nn.Module):
    """ The advanced specialist for solving the geometric problem in one dimension. """
    def __init__(self, dimension: int, num_points: int, feature_dim: int = 64, num_principles: int = 3):
        super().__init__()
        self.dimension = dimension
        self.feature_dim = feature_dim
        print(f"  [CONSTRUCTOR] Initializing a new GeometricMetaSpecialist for {dimension}D.")
        print(f"    > Internal 'thought vector' dimensionality: {feature_dim}")
        print(f"    > Number of learnable 'first principles': {num_principles}")

        self.feature_extractor = nn.Sequential(
            nn.Linear(dimension, 96), nn.ReLU(), nn.LayerNorm(96),
            nn.Linear(96, self.feature_dim), nn.ReLU()
        )
        self.principle_embeddings = nn.Parameter(torch.randn(num_principles, self.feature_dim))
        self.strategy_selector = nn.Sequential(
            nn.Linear(self.feature_dim, 32), nn.ReLU(),
            nn.Linear(32, num_principles), nn.Softmax(dim=-1)
        )
        self.scoring_head = nn.Linear(self.feature_dim, 1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        batch_size, N, D = x.shape
        x_flat = x.view(-1, D)
        features = self.feature_extractor(x_flat)
        strategy_weights = self.strategy_selector(features)
        strategy_applied = torch.matmul(strategy_weights, self.principle_embeddings)
        enhanced_features = features + 0.1 * strategy_applied
        scores = self.scoring_head(enhanced_features)
        return scores.view(batch_size, N)

# =============================================================================
# 4. THE FORGE - ORCHESTRATION LOGIC
# =============================================================================

class PantheonMetaForge:
    def __init__(self, feature_dim=64):
        self.specialists: Dict[int, GeometricMetaSpecialist] = {}
        self.universal_commutator = HolographicCommutator(feature_dim)
        self.feature_dim = feature_dim

    def train_specialist(self, D: int, N: int, epochs_l1: int, epochs_l2: int, batch_size: int):
        print(f"\n{'='*25} FORGING META-SPECIALIST for {D}-DIMENSIONS {'='*25}")
        specialist = GeometricMetaSpecialist(D, N, self.feature_dim)
        optimizer = optim.Adam(specialist.parameters(), lr=0.0001)
        criterion = nn.CrossEntropyLoss()

        # --- SEMESTER 1: Grounding in simple Euclidean space ---
        print(f"\n--- [SEMESTER 1] Training on Euclidean basics for {epochs_l1} epochs ---")
        for epoch in range(epochs_l1):
            inputs, labels = generate_euclidean_batch(batch_size, D, N)
            optimizer.zero_grad(); outputs = specialist(inputs); loss = criterion(outputs, labels); loss.backward(); optimizer.step()
            if epoch % 50 == 0 or epoch == epochs_l1 - 1:
                print(f"     > L1 Epoch [{epoch+1}/{epochs_l1}] - Current Batch Loss: {loss.item():.4f}")

        # --- Evaluate performance on Semester 1 tasks ---
        with torch.no_grad():
            test_inputs, test_labels = generate_euclidean_batch(1000, D, N)
            accuracy_l1 = (torch.max(specialist(test_inputs), 1)[1] == test_labels).sum().item() / 1000
        print(f"--- [EVAL] Semester 1 Complete. Euclidean Accuracy: {accuracy_l1*100:.2f}% ---")
        if accuracy_l1 < 0.8:
            print(f"   ❌ FAILED: Accuracy below 80% threshold. Specialist for {D}D is not viable. Aborting.")
            return None

        # --- SEMESTER 2: Mastering complex Curved space ---
        print(f"\n--- [SEMESTER 2] Training on Curved Space (Max {epochs_l2} epochs w/ Early Stopping) ---")
        best_loss = float('inf'); epochs_no_improve = 0; patience = 95; best_model_state_dict = copy.deepcopy(specialist.state_dict())
        
        iterator = tqdm(range(epochs_l2), desc=f"Meta-Forge {D}D Curved Space")
        for epoch in iterator:
            inputs, labels = generate_curved_space_batch(batch_size, D, N)
            optimizer.zero_grad(); outputs = specialist(inputs); loss = criterion(outputs, labels); loss.backward(); optimizer.step()
            
            if loss.item() < best_loss:
                best_loss, epochs_no_improve, best_model_state_dict = loss.item(), 0, copy.deepcopy(specialist.state_dict())
            else:
                epochs_no_improve += 1
            if epochs_no_improve >= patience:
                print(f"\n     > 🛑 Early stopping triggered at epoch {epoch+1}. Best loss of {best_loss:.4f} achieved.")
                break
        
        print(f"--- [FINALIZE] Loading best performing model weights for {D}D Specialist. ---")
        specialist.load_state_dict(best_model_state_dict)
        
        # --- Final evaluation on Semester 2 tasks ---
        with torch.no_grad():
            test_inputs, test_labels = generate_curved_space_batch(1000, D, N)
            accuracy_l2 = (torch.max(specialist(test_inputs), 1)[1] == test_labels).sum().item() / 1000
            
        print(f"✅✅✅ META-{D}D SPECIALIST FORGED! Final Curved Space Accuracy: {accuracy_l2*100:.2f}% ✅✅✅")
        self.specialists[D] = specialist
        return specialist

    def train_holographic_commutator(self, dimensions: List[int], max_steps: int = 20000, patience: int = 95):
        print(f"\n{'='*20} FORGING HOLOGRAPHIC COMMUTATOR (Universal Bridge) {'='*20}")
        print("This component will learn to translate 'thoughts' between any two specialists.")
        print(f"It will be trained on {max_steps} examples of translation tasks.")
        
        optimizer = optim.Adam(self.universal_commutator.parameters(), lr=0.001)
        criterion = nn.MSELoss()
        best_loss = float('inf'); best_state = None; no_improve = 0
        
        iterator = tqdm(range(max_steps), desc="Forging Hologram")
        for step in iterator:
            src_dim, tgt_dim = np.random.choice(dimensions, 2, replace=False)
            src_inputs, _ = generate_curved_space_batch(32, src_dim, 15)
            tgt_inputs, _ = generate_curved_space_batch(32, tgt_dim, 15)

            with torch.no_grad():
                src_feat = self.specialists[src_dim].feature_extractor(src_inputs.view(-1, src_dim)).view(32, 15, -1).mean(dim=1)
                tgt_feat = self.specialists[tgt_dim].feature_extractor(tgt_inputs.view(-1, tgt_dim)).view(32, 15, -1).mean(dim=1)

            warped_feat = self.universal_commutator.transfer(src_feat, src_dim, tgt_dim)
            loss = criterion(warped_feat, tgt_feat)
            loss.backward(); optimizer.step()
            
            iterator.set_postfix({'loss': f'{loss.item():.5f}', 'map': f'{src_dim}D->{tgt_dim}D'})
            if loss.item() < best_loss:
                best_loss, no_improve, best_state = loss.item(), 0, copy.deepcopy(self.universal_commutator.state_dict())
            else:
                no_improve += 1
            if no_improve >= patience:
                print(f"\n     > 🛑 Commutator has converged. Early stopping at step {step}.")
                break
        
        if best_state: self.universal_commutator.load_state_dict(best_state)
        print(f"✅✅✅ HOLOGRAPHIC BRIDGE ESTABLISHED! Best Translation Loss: {best_loss:.5f} ✅✅✅")

    def save_pantheon(self, filename: str = "PantheonMetaForge_Geometric_v1.json"):
        print(f"\n{'='*30} SAVING ENTIRE SYSTEM {'='*30}")
        print(f"Serializing all components into a single file: {filename}")
        
        def make_serializable(obj):
            if isinstance(obj, torch.Tensor): return obj.detach().cpu().numpy().tolist()
            if isinstance(obj, dict): return {k: make_serializable(v) for k, v in obj.items()}
            return obj

        output_data = {
            'system_name': 'PantheonMetaForge_Geometric',
            'timestamp': time.time(),
            'meta_pantheon': {
                str(dim): {'state_dict': make_serializable(spec.state_dict())}
                for dim, spec in self.specialists.items()
            },
            'holographic_commutator': make_serializable(self.universal_commutator.state_dict())
        }
            
        with open(filename, 'w') as f:
            json.dump(output_data, f, indent=2)
        print(f"✅ SYSTEM SAVED SUCCESSFULLY.")

# =============================================================================
# 5. EXECUTION
# =============================================================================
if __name__ == "__main__":
    start_time = time.time()
    
    # --- System Parameters ---
    N_POINTS = 15
    EPOCHS_L1 = 550
    EPOCHS_L2 = 19000
    BATCH_SIZE = 512
    DIMENSIONS_TO_TRAIN = list(range(3, 13))
    
    # --- Initialize the Forge ---
    forge = PantheonMetaForge(feature_dim=64)
    
    # --- STEP 1: Train all the advanced specialists ---
    print("\n\n--- MAIN PHASE 1: FORGING INDIVIDUAL SPECIALISTS ---")
    for D in DIMENSIONS_TO_TRAIN:
        forge.train_specialist(D, N_POINTS, EPOCHS_L1, EPOCHS_L2, BATCH_SIZE)
        
    # --- STEP 2: Train the Universal Bridge between them ---
    print("\n\n--- MAIN PHASE 2: FORGING THE HOLOGRAPHIC BRIDGE ---")
    if len(forge.specialists) < 2:
        print("❌ CRITICAL: Not enough successful specialists were forged (<2). Cannot build the bridge.")
    else:
        successful_dims = sorted(forge.specialists.keys())
        print(f"Sufficient specialists ({len(successful_dims)}) created. Proceeding to train the translator.")
        forge.train_holographic_commutator(successful_dims, max_steps=45000, patience=95)
    
    # --- STEP 3: Save the entire system ---
    print("\n\n--- MAIN PHASE 3: CONSOLIDATING AND SAVING THE PANTHEON ---")
    forge.save_pantheon()

    # --- FINAL SUMMARY ---
    total_time = time.time() - start_time
    print(f"\n{'='*80}")
    print(f"🎉🎉🎉 PANTHEON META-FORGE COMPLETE in {total_time/60:.2f} minutes. 🎉🎉🎉")
    print("The advanced Geometric Pantheon, with its universal meta-language, is now ready.")
    print("=" * 80)