# Filename: PantheonForge_Sequential.py
# The definitive Curriculum Engine to forge the E2 Pantheon.
# --- MODIFIED to run sequentially (one at a time) ---

import json
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import os
import time
# --- MODIFICATION: Removed multiprocessing imports ---
# from multiprocessing import Pool, cpu_count, Manager 

# --- (SpecialistModel is unchanged and stable) ---
class SpecialistModel(nn.Module):
    def __init__(self, D_in, N_in):
        super(SpecialistModel, self).__init__()
        self.D = D_in
        self.N = N_in
        self.feature_extractor = nn.Sequential(nn.Linear(self.D, 96), nn.Sigmoid(), nn.LayerNorm(96), nn.Linear(96, 48), nn.Sigmoid())
        self.scoring_head = nn.Linear(48, 1)
        self.project_to_latent = nn.Linear(48, 16)
        self.project_from_latent = nn.Linear(16, 48)
    def forward(self, x):
        features = self.feature_extractor(x)
        scores = self.scoring_head(features).squeeze(-1)
        return scores

# --- (Data Generators are verified and stable) ---
def generate_euclidean_batch(batch_size, D, N):
    points = torch.randn(batch_size, N, D)
    distances = torch.norm(points, dim=2)
    labels = torch.argmin(distances, dim=1)
    return points, labels

def generate_curved_space_batch(batch_size, D, N, space_curvature=0.5):
    positions = torch.randn(batch_size, N, D) * 2
    base_metric = torch.eye(D).unsqueeze(0).repeat(batch_size, 1, 1)
    noise = torch.randn(batch_size, D, D) * space_curvature
    symmetric_noise = (noise + noise.transpose(1, 2)) / 2
    curvature_matrix = base_metric + symmetric_noise
    curved_positions = torch.bmm(positions, curvature_matrix)
    p_i = curved_positions.unsqueeze(2); p_j = curved_positions.unsqueeze(1); delta = p_i - p_j
    batch_size_val, N_val, _, D_val = delta.shape
    delta_reshaped = delta.reshape(batch_size_val * N_val * N_val, 1, D_val)
    curvature_matrix_expanded = curvature_matrix.repeat_interleave(N_val * N_val, dim=0)
    delta_transformed = torch.bmm(delta_reshaped, curvature_matrix_expanded).reshape(batch_size_val, N_val, N_val, D_val)
    dist_sq = torch.sum(delta * delta_transformed, dim=-1)
    dist_sq = dist_sq + torch.eye(N) * 1e9
    min_distances_per_sphere = torch.sqrt(torch.min(dist_sq, dim=2).values)
    labels = torch.argmax(min_distances_per_sphere, dim=1)
    centroid = torch.mean(curved_positions, dim=1, keepdim=True)
    final_input = curved_positions - centroid
    return final_input, labels

# --- The Worker Function for Training ---
# --- MODIFICATION: Removed 'lock' from arguments ---
def train_and_save_worker(args):
    D, N, num_epochs_l1, num_epochs_l2, batch_size, pantheon_dict = args
    process_id = os.getpid()
    
    # --- SEMESTER 1: Freshman Year ---
    print(f"[{process_id}] Starting E1 training for {D}D Specialist...")
    model = SpecialistModel(D, N)
    optimizer = optim.Adam(model.parameters(), lr=0.001)
    criterion = nn.CrossEntropyLoss()
    for epoch in range(num_epochs_l1):
        inputs, labels = generate_euclidean_batch(batch_size, D, N)
        optimizer.zero_grad(); outputs = model(inputs); loss = criterion(outputs, labels)
        loss.backward(); optimizer.step()
    
    # Evaluate E1
    with torch.no_grad():
        test_inputs, test_labels = generate_euclidean_batch(1000, D, N)
        accuracy_l1 = (torch.max(model(test_inputs), 1)[1] == test_labels).sum().item() / 1000
    print(f"[{process_id}] E1 for {D}D complete. Accuracy: {accuracy_l1*100:.2f}%")

    if accuracy_l1 < 0.8:
        print(f"[{process_id}] WARNING: E1 training for {D}D failed. Aborting.")
        return

    # --- SEMESTER 2: Sophomore Year (with Early Stopping) ---
    print(f"[{process_id}] Starting E2 training for {D}D Specialist with Early Stopping...")
    
    best_loss = float('inf')
    epochs_no_improve = 0
    patience = 21
    best_model_state_dict = model.state_dict()

    for epoch in range(num_epochs_l2):
        inputs, labels = generate_curved_space_batch(batch_size, D, N)
        optimizer.zero_grad(); outputs = model(inputs); loss = criterion(outputs, labels)
        loss.backward(); optimizer.step()
        
        if loss.item() < best_loss:
            best_loss = loss.item()
            epochs_no_improve = 0
            best_model_state_dict = model.state_dict()
        else:
            epochs_no_improve += 1
        
        if epochs_no_improve >= patience:
            print(f"[{process_id}] E2 {D}D: Early stopping triggered at epoch {epoch+1}. Best loss: {best_loss:.4f}")
            break
            
    print(f"[{process_id}] E2 {D}D: Loading best model weights for final evaluation.")
    model.load_state_dict(best_model_state_dict)
        
    # Evaluate E2
    with torch.no_grad():
        test_inputs, test_labels = generate_curved_space_batch(1000, D, N)
        accuracy_l2 = (torch.max(model(test_inputs), 1)[1] == test_labels).sum().item() / 1000
    print(f"[{process_id}] E2 for {D}D complete. Accuracy: {accuracy_l2*100:.2f}%")

    # --- Prepare weights for saving ---
    state_dict = model.state_dict()
    weights_dict = { name: tensor.cpu().numpy().tolist() for name, tensor in state_dict.items() }
    
    final_weights = {
        "feature_extractor": { "W": [weights_dict['feature_extractor.0.weight'], weights_dict['feature_extractor.3.weight']], "b": [weights_dict['feature_extractor.0.bias'], weights_dict['feature_extractor.3.bias']] },
        "scoring_head": {"W": [weights_dict['scoring_head.weight']], "b": [weights_dict['scoring_head.bias']]},
        "project_to_latent": {"W": [weights_dict['project_to_latent.weight']], "b": [weights_dict['project_to_latent.bias']]},
        "project_from_latent": {"W": [weights_dict['project_from_latent.weight']], "b": [weights_dict['project_from_latent.bias']]}
    }
    
    specialist_data = { "dimensionality": D, "accuracy": accuracy_l2, "weights": final_weights }
    
    # --- MODIFICATION: Directly write to the standard dictionary (no lock needed) ---
    pantheon_dict[str(D)] = specialist_data
    print(f"[{process_id}] {D}D Specialist weights prepared for saving.")

# --- Main Execution Block ---
if __name__ == "__main__":
    start_time = time.time()
    
    # --- MODIFICATION: Use a standard Python dictionary instead of a Manager ---
    pantheon_dict = {}
    
    # Training Parameters (unchanged)
    N_POINTS = 15
    EPOCHS_L1 = 150
    EPOCHS_L2 = 7000 
    BATCH_SIZE = 512
    DIMENSIONS_TO_TRAIN = list(range(3, 13))

    # --- MODIFICATION: Adjust tasks to not include the lock ---
    tasks = [(D, N_POINTS, EPOCHS_L1, EPOCHS_L2, BATCH_SIZE, pantheon_dict) for D in DIMENSIONS_TO_TRAIN]
    
    # --- MODIFICATION: Replace the multiprocessing pool with a simple for loop ---
    print(f"Starting sequential training for dimensions {DIMENSIONS_TO_TRAIN}...")

    # --- Forge one-by-one ---
    for task in tasks:
        train_and_save_worker(task)
        
    print("\n--- All training complete. Consolidating Pantheon... ---")
    
    # Consolidate the final Pantheon file
    final_pantheon = {"latent_dim": 16, "pantheon": pantheon_dict}
    
    with open('EAMC_weights_v3.json', 'w') as f:
        json.dump(final_pantheon, f, indent=4)

    total_time = time.time() - start_time
    print(f"\n✅ New Pantheon forged and saved to EAMC_weights_v2.json in {total_time/60:.2f} minutes.")